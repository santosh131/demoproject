CREATE TYPE role_menu_ut AS Table
(
 menu_action_id varchar(50),
 selected_ind bit
)