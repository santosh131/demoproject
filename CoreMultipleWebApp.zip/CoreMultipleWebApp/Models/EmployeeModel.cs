﻿using System.ComponentModel.Design.Serialization;

namespace Models
{
    [Serializable]
    public class EmployeeModel :BaseModel
    {
        public int Id { get; set; }

        public string Name { get; set; } = string.Empty;

    }
}
