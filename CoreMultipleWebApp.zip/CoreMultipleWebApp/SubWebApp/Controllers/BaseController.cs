﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace SubWebApp.Controllers
{
    [ApiController]
    public class BaseController : ControllerBase
    {
        [FromHeader(Name = "X-User-Id")]
        public int UserId { get; set; }

        [FromHeader(Name = "X-User-Name")]
        public string UserName { get; set; } = string.Empty;

        [FromHeader(Name = "X-Entity-Said")]
        public int EntitySaid { get; set; }

        [FromHeader(Name = "X-User-Entity-Said")]
        public int UserEntitySaid { get; set; }
    }
}
