using Microsoft.AspNetCore.Mvc;
using Models;
using System.Net;

namespace SubWebApp.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : BaseController
    {

        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        [Route("GetWeatherForecastAsync")]
        [ProducesResponseType(typeof(WeatherForecast), 200)]
        public async Task<IEnumerable<WeatherForecast>> GetWeatherForecastAsync()
        {
            _logger.LogInformation($"SubWebApp Get Success UserInfo: {UserId} {UserName} {EntitySaid} {UserEntitySaid}");
            return await Task.Run(() =>
            {
                return Enumerable.Range(1, 5).Select(index => new WeatherForecast
                {
                    Date = DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
                    TemperatureC = Random.Shared.Next(-20, 55),
                    Summary = Summaries[Random.Shared.Next(Summaries.Length)]
                })
                .ToArray();
            }).ConfigureAwait(false);
        }

        [HttpPost]
        [Route("PostWeatherForecastAsync")]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.OK)]
        public async Task<string> PostWeatherForecastAsync([FromBody]EmployeeModel employeeModel    )
        {
            return await Task.Run(() =>
            {
                return $"Post Success UserInfo: {UserId} {UserName} {EntitySaid} {UserEntitySaid} EmployeeInfo: {employeeModel.Name}";
            }).ConfigureAwait(false);
        }
    }
}
