using CoreMultipleWebApp.Helper;
using DataTransferObjects;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Net.Http;
using System.Text;

namespace CoreMultipleWebApp.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : BaseController
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IHttpHelpers _httpHelpers;


        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger, IHttpClientFactory httpClientFactory,IHttpHelpers httpHelpers)
        {
            _logger = logger;
            _httpClientFactory = httpClientFactory;
            _httpHelpers = httpHelpers;
        }

        [HttpGet]
        [Route("GetWeatherForecastAsync")]
        [ProducesResponseType(typeof(string), 200)]

        public async Task<string> GetWeatherForecastAsync()
        {
            //HttpClient client = _httpClientFactory.CreateClient("MyHttpClient");
            HttpResponseMessage response = await _httpHelpers.GetAsync("WeatherForecast/GetWeatherForecastAsync");// await client.GetAsync("WeatherForecast/GetWeatherForecastAsync");

            if (response.IsSuccessStatusCode)
            {
                _logger.LogInformation("Success retrieving data from sub project");
                return await response.Content.ReadAsStringAsync();
            }
            else
            {
                return $"Error: {response.ToString()}";
            }
        }

        /// <summary>
        /// PostWeatherForecastAsync Method
        /// </summary>
        /// <param name="employeeDTO">EmployeeDTO</param>
        /// <returns>string</returns>
        [HttpPost]
        [Route("PostWeatherForecastAsync")]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.OK)]
        
        public async Task<string> PostWeatherForecastAsync([FromBody] EmployeeDTO employeeDTO) 
        {           
            string eContent = System.Text.Json.JsonSerializer.Serialize(employeeDTO);
            var content = new StringContent(eContent, Encoding.UTF8, "application/json");
            HttpClient client = _httpClientFactory.CreateClient("MyHttpClient");

            client.DefaultRequestHeaders.Add("X-User-Id", 10.ToString());
            client.DefaultRequestHeaders.Add("X-User-Name", "Santosh".ToString());
            client.DefaultRequestHeaders.Add("X-Entity-Said", 20.ToString());
            client.DefaultRequestHeaders.Add("X-User-Entity-Said", 100.ToString());

            HttpResponseMessage response = await client.PostAsync("WeatherForecast/PostWeatherForecastAsync", content);

            if (response.IsSuccessStatusCode)
            {
                _logger.LogInformation("Success retrieving data from sub project");
                return await response.Content.ReadAsStringAsync();
            }
            else
            {
                return $"Error: {response.ToString()}";
            }
        }
    }
}
