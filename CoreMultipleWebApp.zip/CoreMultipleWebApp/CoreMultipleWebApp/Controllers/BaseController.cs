﻿using Microsoft.AspNetCore.Mvc;

namespace CoreMultipleWebApp.Controllers
{

    [ApiController]
    public class BaseController : ControllerBase
    {
        

    }
}
