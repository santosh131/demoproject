using CoreMultipleWebApp.Helper;
using Microsoft.Extensions.Configuration;

var builder = WebApplication.CreateBuilder(args);


builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.AddDebug();

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddTransient<IHttpHelpers, HttpHelpers>();
string apiClientKey = builder.Configuration.GetValue<string>("apiClientUrlKey") ?? "";

string apiClientUrlText = builder.Configuration.GetValue<string>("apiClientUrlText") ?? "";

builder.Services.AddHttpClient(apiClientKey, client =>
{
    client.BaseAddress = new Uri(apiClientUrlText);
});

var app = builder.Build();

app.Logger.LogInformation("Started loggin CoreMulApp");


// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
