﻿using Microsoft.Extensions.Configuration;
using System.Net.Http;

namespace CoreMultipleWebApp.Helper
{
    public class HttpHelpers : IHttpHelpers
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _configuration;
        public HttpHelpers(IHttpClientFactory httpClientFactory, IConfiguration configuration) {
            _httpClientFactory = httpClientFactory;
            _configuration = configuration;
        }
        public async Task<HttpResponseMessage> GetAsync(string urlText)
        {
            string defaultApiClientKey = _configuration.GetValue<string>("apiClientUrlKey") ?? "";
            return await GetAsync(urlText, defaultApiClientKey);
        }
        public async Task<HttpResponseMessage> GetAsync(string urlText, string apiClientKey)
        {
            HttpClient client = _httpClientFactory.CreateClient(apiClientKey);

            client.DefaultRequestHeaders.Add("X-User-Id", 10.ToString());
            client.DefaultRequestHeaders.Add("X-User-Name", "Santosh".ToString());
            client.DefaultRequestHeaders.Add("X-Entity-Said", 20.ToString());
            client.DefaultRequestHeaders.Add("X-User-Entity-Said", 100.ToString());
            return await client.GetAsync(urlText);

        }
    }
}
