﻿namespace CoreMultipleWebApp.Helper
{
    public interface IHttpHelpers
    {
        Task<HttpResponseMessage> GetAsync(string urlText, string apiClientKey);
        Task<HttpResponseMessage> GetAsync(string urlText);
    }
}
