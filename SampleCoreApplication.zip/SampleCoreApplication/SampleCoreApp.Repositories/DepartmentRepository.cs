﻿using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.Extensions;
using SampleCoreApp.Infrastructure.Base.Interfaces;
using SampleCoreApp.Infrastructure.Base.Models;
using SampleCoreApp.Infrastructure.BaseModels;

using SampleCoreApp.Interfaces.Repositories;
using SampleCoreApp.Models.Models.SampleModuleModel;
using System;
using System.Collections.Generic;
using System.Data;

namespace SampleCoreApp.Repositories
{
    public class DepartmentRepository : RepositoryHelper, IDepartmentRepository
    {
        public DepartmentRepository(IDbHelper dbHelper):base(dbHelper)
        {

        }

        public List<DepartmentModel> GetAll(DepartmentModel t, CommonModel tcommon, ref MessageModel tmessage, ref SortingPagingModel tSortingPaging)
        {
            DbHelper.SetQuery("GET_DEPARTMENTS_POPUP_LIST", CommandType.StoredProcedure);
            DbHelper.CreateParameter("@pin_department_id", t.DepartmentId, DbType.Int32, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_department_name", t.DepartmentName, DbType.String, ParameterDirection.Input);

            DbHelper.CreateParameter("@pin_option_cd", tcommon.OptionCode, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_list_type_cd", tcommon.ListTypeCode, DbType.String, ParameterDirection.Input);

            DbHelper.CreateParameter("@pout_msg_cd", null, DbType.String, ParameterDirection.Output, 20);
            DbHelper.CreateParameter("@pout_msg_txt", null, DbType.String, ParameterDirection.Output, 250);

            List<DepartmentModel> lst = DbHelper.ExecuteReader().ToCollectionUsingMethod<DepartmentModel>();
            tmessage.MessageCode = DbHelper.GetOutputParameterStringValue("@pout_msg_cd");
            tmessage.MessageText = DbHelper.GetOutputParameterStringValue("@pout_msg_txt");
            return lst;
        }
    }
}
