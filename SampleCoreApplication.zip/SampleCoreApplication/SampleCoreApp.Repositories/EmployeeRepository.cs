﻿using SampleCoreApp.Infrastructure.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.Extensions;
using SampleCoreApp.Infrastructure.Base.Interfaces;
using SampleCoreApp.Infrastructure.Base.Models;
using SampleCoreApp.Infrastructure.BaseModels;

using SampleCoreApp.Interfaces.Repositories;
using SampleCoreApp.Models.Models.SampleModuleModel;
using System;
using System.Collections.Generic;
using System.Data;


namespace SampleCoreApp.Repositories
{
    public class EmployeeRepository : RepositoryHelper, IEmployeeRepository
    {
        public EmployeeRepository(IDbHelper dbHelper) : base(dbHelper)
        {
        }


        public EmployeeModel Get(EmployeeModel t, CommonModel tcommon, ref MessageModel tmessage)
        {
            SortingPagingModel tSortingPaging = new();
            List<EmployeeModel> employeeModels = GetAll(t, tcommon, ref tmessage, ref tSortingPaging);
            if (employeeModels.Count > 0)
                return employeeModels[0];
            else
                return null;
        }

        public List<EmployeeModel> GetAll(EmployeeModel t, CommonModel tcommon, ref MessageModel tmessage, ref SortingPagingModel tSortingPaging)
        {
            DbHelper.SetQuery("GET_EMPLOYEES", CommandType.StoredProcedure);
            DbHelper.CreateParameter("@pin_emp_id", t.EmployeeId, DbType.Int32, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_emp_first_name", t.FirstName, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_emp_last_name", t.LastName, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_action_cd", tcommon.ActionCode, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_list_type_cd", tcommon.ListTypeCode, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_sort_col_name_txt", t.GetDBColumnName(tSortingPaging.SortText), DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_sort_order", tSortingPaging.SortOrder, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_current_page_index", tSortingPaging.CurrentPageIndex, DbType.Int32, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_page_size_nbr", tSortingPaging.ItemsPerPage, DbType.Int32, ParameterDirection.Input);

            DbHelper.CreateParameter("@pout_msg_cd", null, DbType.String, ParameterDirection.Output, 20);
            DbHelper.CreateParameter("@pout_msg_txt", null, DbType.String, ParameterDirection.Output, 250);
            DbHelper.CreateParameter("@pout_tot_page_nbr", null, DbType.Int32, ParameterDirection.Output, 250);
            List<EmployeeModel> lst = DbHelper.ExecuteReader().ToCollectionUsingMethod<EmployeeModel>();
            tmessage.MessageCode = DbHelper.GetOutputParameterStringValue("@pout_msg_cd");
            tmessage.MessageText = DbHelper.GetOutputParameterStringValue("@pout_msg_txt");
            tSortingPaging.TotalPages = DbHelper.GetOutputParameterIntegerValue("@pout_tot_page_nbr");
            return lst;
        }

        public void Validate(EmployeeModel t, CommonModel tcommon, ref MessageModel tmessage)
        {
            DbHelper.SetQuery("VALIDATE_EMPLOYEES", CommandType.StoredProcedure);
            DbHelper.CreateParameter("@pin_emp_id", t.EmployeeId, DbType.Int32, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_emp_first_name", t.FirstName, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_emp_last_name", t.LastName, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_emp_email", t.Email, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_emp_phone_number", t.PhoneNumber, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_emp_hire_dt", t.HireDate, DbType.Date, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_emp_job_id", t.JobId, DbType.Int32, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_emp_salary", t.Salary, DbType.Decimal, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_emp_manager_id", t.ManagerId, DbType.Int32, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_emp_department_id", t.DepartmentId, DbType.Int32, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_action_cd", tcommon.ActionCode, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_update_type_cd", tcommon.UpdateTypeCode, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pout_msg_cd", null, DbType.String, ParameterDirection.Output, 20);
            DbHelper.CreateParameter("@pout_msg_txt", null, DbType.String, ParameterDirection.Output, 250);
            tmessage.MessageModels = DbHelper.ExecuteReader().ToCollectionUsingMethod<MessageModel>();
            tmessage.MessageCode = DbHelper.GetOutputParameterStringValue("@pout_msg_cd");
            tmessage.MessageText = DbHelper.GetOutputParameterStringValue("@pout_msg_txt");            
        }

        public void Save(EmployeeModel t, CommonModel tcommon, ref MessageModel tmessage)
        {
            DbHelper.SetQuery("INSERT_UPDATE_DELETE_EMPLOYEES", CommandType.StoredProcedure);
            DbHelper.CreateParameter("@pin_emp_id", t.EmployeeId, DbType.Int32, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_emp_first_name", t.FirstName, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_emp_last_name", t.LastName, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_emp_email", t.Email, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_emp_phone_number", t.PhoneNumber, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_emp_hire_dt", t.HireDate, DbType.Date, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_emp_job_id", t.JobId, DbType.Int32, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_emp_salary", t.Salary, DbType.Decimal, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_emp_manager_id", t.ManagerId, DbType.Int32, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_emp_department_id", t.DepartmentId, DbType.Int32, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_action_cd", tcommon.ActionCode, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_update_type_cd", tcommon.UpdateTypeCode, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pout_msg_cd", null, DbType.String, ParameterDirection.Output, 20);
            DbHelper.CreateParameter("@pout_msg_txt", null, DbType.String, ParameterDirection.Output, 250);
            DbHelper.ExecuteNonQuery();
            tmessage.MessageCode = DbHelper.GetOutputParameterStringValue("@pout_msg_cd");
            tmessage.MessageText = DbHelper.GetOutputParameterStringValue("@pout_msg_txt");
        }

        
    }
}
