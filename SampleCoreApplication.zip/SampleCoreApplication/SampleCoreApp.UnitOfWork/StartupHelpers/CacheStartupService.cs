﻿using SampleCoreApp.Infrastructure.Base.Interfaces;
using SampleCoreApp.Infrastructure.Base.Models;
using SampleCoreApp.Infrastructure.BaseModels;
using SampleCoreApp.Interfaces.Repositories;
using System.Collections.Generic;
using System.Linq;
using SampleCoreApp.Infrastructure.Constants;
using System;

namespace SampleCoreApp.UnitOfWork.StartupHelpers
{
    public class CacheStartupService
    {
        private readonly ICacheHelper _cacheHelper;
        private readonly ILookupRepository _lookupRepository;

        public CacheStartupService(ICacheHelper cacheHelper, ILookupRepository lookupRepository)
        {
            _cacheHelper = cacheHelper;
            _lookupRepository = lookupRepository;
        }

        /// <summary>
        /// Sets the cache
        /// </summary>
        public void SetCache()
        {
            _cacheHelper.ClearAllCache();

            SetFieldCodeModelsToCache();

            SetFieldValueModelsToCache();

            SetMessageModelsToCache();

            SetMenuModelsToCache();
        }

        private void SetFieldValueModelsToCache()
        {
            CommonModel commonModel = new();
            MessageModel messageModel = new();

            List<FieldValueModel> fieldCodeModels = _lookupRepository.GetFieldValuesLookup(new FieldValueModel(), ref commonModel, ref messageModel).ToList();
            //Dictionary<string, FieldCodeModel> keyValuePairs = new();

            //foreach (var item in fieldCodeModels)
            //{
            //    keyValuePairs.Add($"{item.FieldCode}{ApplicationConstants.FieldCodePageCodeSeparator}{item.PageCode}", item);
            //}
            _cacheHelper.SetToCache(ApplicationConstants.CacheKeys.FieldValues, fieldCodeModels);
        }

        /// <summary>
        /// Sets the Field Code Models to cache
        /// </summary>
        private void SetFieldCodeModelsToCache()
        {
            CommonModel commonModel = new();
            MessageModel messageModel = new();

            List<FieldCodeModel> fieldCodeModels = _lookupRepository.GetFieldCodeLookup(new FieldCodeModel(), ref commonModel, ref messageModel).ToList();
            Dictionary<string, FieldCodeModel> keyValuePairs = new();

            foreach (var item in fieldCodeModels)
            {
                keyValuePairs.Add($"{item.FieldCode}{ApplicationConstants.FieldCodePageCodeSeparator}{item.PageCode}", item);
            }
            _cacheHelper.SetToCache(ApplicationConstants.CacheKeys.FieldCode, keyValuePairs);
        }

        /// <summary>
        /// Sets the Message Code Models to cache
        /// </summary>
        private void SetMessageModelsToCache()
        {
            CommonModel commonModel = new();
            MessageModel messageModel = new();

            List<MessageModel> messageModels = _lookupRepository.GetMessageCodeLookup(new MessageModel(), ref commonModel, ref messageModel).ToList();
            Dictionary<string, MessageModel> keyValuePairs = new();

            foreach (var item in messageModels)
            {
                keyValuePairs.Add(item.MessageCode, item);
            }
            _cacheHelper.SetToCache(ApplicationConstants.CacheKeys.MessageCode, keyValuePairs);
        }


        /// <summary>
        /// Sets the Menu Models to cache
        /// </summary>
        private void SetMenuModelsToCache()
        {
            
        }
    }
}
