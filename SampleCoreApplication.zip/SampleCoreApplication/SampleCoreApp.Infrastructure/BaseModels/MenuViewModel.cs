﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.BaseModels
{
    public class MenuViewModel: BaseViewModel
    {
        public List<MenuModel> MenuModels { get; set; }

        public string ApplicationName { get; set; }
    }
}
