﻿using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.BaseModels
{
    [Serializable]
    public class BaseDto : ModelHelper
    {
        private AdditionalInfoModel _AdditionalInfoModel = new();

        public AdditionalInfoModel AdditionalInfoModel { get => _AdditionalInfoModel; set => _AdditionalInfoModel = value; }

    }
}
