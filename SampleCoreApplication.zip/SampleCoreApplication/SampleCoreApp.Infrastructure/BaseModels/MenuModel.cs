﻿using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.Constants;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace SampleCoreApp.Infrastructure.BaseModels
{
    public class MenuModel: ModelHelper
    {
        public string MenuId { get; set; }

        public string MenuName { get; set; }

        public string ParentMenuId { get; set; }

        public string MenuControllerName { get; set; }

        public string MenuActionName { get; set; }

        public string MenuAreaName { get; set; } = "";

        public bool IsChildMenu { get; set; } = false;

        public List<MenuModel> ChilMenus { get; set; }
    }
}
