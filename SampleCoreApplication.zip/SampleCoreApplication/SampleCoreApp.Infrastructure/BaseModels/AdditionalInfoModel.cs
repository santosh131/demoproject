﻿using System;
using System.Collections.Generic;
using System.Text;
using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.Models;

namespace SampleCoreApp.Infrastructure.BaseModels
{
    [Serializable]
    public class AdditionalInfoModel
    {
        private MessageModel _messageModel = new();
        private SortingPagingModel _SortingPagingModel = new();
       
        public MessageModel MessageModel { get => _messageModel; set => _messageModel = value; }
        public SortingPagingModel SortingPagingModel { get => _SortingPagingModel; set => _SortingPagingModel = value; }
    }
}
