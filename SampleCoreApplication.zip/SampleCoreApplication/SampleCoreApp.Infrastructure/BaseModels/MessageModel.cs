﻿using SampleCoreApp.Infrastructure.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.Constants;
using SampleCoreApp.Infrastructure.Base.Models;
using SampleCoreApp.Infrastructure.Constants;
using System;
using System.Collections.Generic;
using static SampleCoreApp.Infrastructure.Constants.ApplicationConstants;

namespace SampleCoreApp.Infrastructure.BaseModels
{
    [Serializable]
    public class MessageModel : BaseMessageModel
    {
        private string _messageTypeCode;
        private string _messageType;
        private List<MessageModel> _messageModels = new();
        private string _message_desc;
        private string _additional_msg;
        private string _empty_grid_msg;
        private bool _isJson = false;
        private string _msg_type_icon_class;

        public string MessageTypeIconClass { get => _msg_type_icon_class; set => _msg_type_icon_class = value; }



        public MessageModel()
        {

        }

        public MessageModel(bool? setEmptyGrid = false)
        {
            if (setEmptyGrid.HasValue && setEmptyGrid.Value)
                SetEmptyGridMessage();
        }

        [DbColumnName("msg_type_cd")]
        public string MessageTypeCode { get => _messageTypeCode; set => _messageTypeCode = value; }

        [DbColumnName("msg_type_desc")]
        public string MessageType { get => _messageType; set => _messageType = value; }
        //{
        //    get
        //    {
        //        if (!string.IsNullOrEmpty(_messageTypeCode))
        //        {
        //            if (_messageTypeCode.ToUpper() == "S")
        //            {
        //                return MessageTypesConstants.Success;
        //            }
        //            else if (_messageTypeCode.ToUpper() == "E")
        //            {
        //                return MessageTypesConstants.Error;
        //            }
        //            else if (_messageTypeCode.ToUpper() == "W")
        //            {
        //                return MessageTypesConstants.Warning;
        //            }
        //            else if (_messageTypeCode.ToUpper() == "I")
        //            {
        //                return MessageTypesConstants.Information;
        //            }
        //        }
        //        return "";
        //    }
        //}

        public List<MessageModel> MessageModels { get => _messageModels; set => _messageModels = value; }

        [DbColumnName("msg_desc_txt")]
        public string MessageDescription { get => _message_desc; set => _message_desc = value; }

        /// <summary>
        /// Gets or Sets EmptyGridMessage
        /// </summary>
        /// <remarks>
        /// Any Additional Message to be displayed along with the Messages
        /// </remarks>
        public string AdditionalMessage { get => _additional_msg; set => _additional_msg = value; }

        /// <summary>
        /// Gets or Sets EmptyGridMessage
        /// </summary>
        /// <remarks>
        /// Message to be displayed in the grid if row count is zero
        /// </remarks>
        public string EmptyGridMessage { get => _empty_grid_msg; set => _empty_grid_msg = value; }

        /// <summary>
        /// Gets or Sets IsJson
        /// </summary>
        /// <remarks>
        ///  If the response is Json or not
        /// </remarks>
        public bool IsJson { get => _isJson; set => _isJson = value; }

        #region public Methods
        /// <summary>
        /// Sets the empty grid message
        /// </summary>
        public void SetEmptyGridMessage()
        {
            _empty_grid_msg = ApplicationUIValues.NoRecordsFound;
        }

        /// <summary>
        /// Sets the MessageType based on the message from cache
        /// </summary>
        public override void SetMessageTypeFromCache()
        {
            this.SetMessageType(); 
        }

       
        #endregion
    } 
}
