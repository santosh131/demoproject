﻿using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.BaseModels
{
    [Serializable]
    public class TransactionModel
    {
        /// <summary>
        /// Gets or Sets TransactionCode
        /// </summary>
        [DbColumnName("trans_code")]
        public string TransactionCode { get; set; } = "";

        /// <summary>
        /// Gets or Sets TransactionDescription
        /// </summary>
        [DbColumnName("trans_desc_txt")]
        public string TransactionDescription { get; set; } = "";

        /// <summary>
        /// Gets or Sets IsAllowed
        /// </summary> 
        public bool IsAllowed { get; set; } = false;

        /// <summary>
        /// Gets or Sets TransactionAltDescription
        /// </summary>
        /// <remarks>
        /// Should be used if the user has transaction and 
        /// we show different caption instead of TransactionDescription
        /// </remarks>
        public string TransactionAltDescription { get; set; } = "";
    }
}
