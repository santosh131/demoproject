﻿using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.Models;
using System;
using System.Collections.Generic;

namespace SampleCoreApp.Infrastructure.BaseModels
{
    [Serializable]
    public abstract class BaseViewModel : ViewModelHelper
    {

        private AdditionalInfoViewModel _AdditionalInfoViewModel = new();

        public AdditionalInfoViewModel AdditionalInfoViewModel { get => _AdditionalInfoViewModel; set => _AdditionalInfoViewModel = value; }

    }
}
