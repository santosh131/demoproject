﻿using System.Collections.Generic;
using System.Text;
using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.Models;

namespace SampleCoreApp.Infrastructure.BaseModels
{
    public class AdditionalInfoViewModel : AdditionalInfoModel
    {
        private List<TransactionModel> _transactionsModel = new();
        private List<FieldCodeModel> _fieldCodeModels = new();

        public List<TransactionModel> TransactionsModel { get => _transactionsModel; set => _transactionsModel = value; }
        public List<FieldCodeModel> FieldCodeModels { get => _fieldCodeModels; set => _fieldCodeModels = value; }
    }
}
