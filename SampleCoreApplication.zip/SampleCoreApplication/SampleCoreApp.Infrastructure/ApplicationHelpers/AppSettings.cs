﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.ApplicationHelpers
{
    public static class AppSettings
    {
        public static string KeyPhrase { get; set; }
        public static string ApplicationName { get; set; }
        public static bool IsModelOnly { get; set; }=false;         
    }
}
