﻿using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.Interfaces;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace SampleCoreApp.Infrastructure.ApplicationHelpers
{
    public class DbSqlHelper : IDbHelper
    {
        #region Private variables
        private IDbConnection _dbConnection;
        private List<SqlParameter> _queryParameters;
        #endregion

        #region Public Variables
        public string ConnectionString { get; set; }
        public string QueryText;
        public CommandType QueryCommandType;
        public SqlCommand SqlCmd;
        #endregion

        #region Constructor
        /// <summary>
        /// DbSqlHelper Constructor
        /// </summary>
        public DbSqlHelper()
        {
            _dbConnection = new SqlConnection(ConnectionString);
            _queryParameters = new List<SqlParameter>();
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Resets all-Connection, Parameters, QueryText, QueryCommandType, SqlCmd
        /// </summary>
        public void ResetAll()
        {
            if (_dbConnection.State == ConnectionState.Open)
            {
                _dbConnection.Close();
            }
            _dbConnection = new SqlConnection(ConnectionString);
            _queryParameters = new List<SqlParameter>();
            QueryText = string.Empty;
            QueryCommandType = CommandType.StoredProcedure;
            SqlCmd = new SqlCommand();
        }

        /// <summary>
        /// Sets the Connection String
        /// </summary>
        /// <param name="connString"></param>
        public void SetConnectionString(string connString)
        {
            ConnectionString = connString;
        }

        /// <summary>
        /// Sets the query- QueryText, QueryCommandType
        /// </summary>
        /// <param name="queryText"></param>
        /// <param name="queryCommandType"></param>
        public void SetQuery(string queryText, CommandType queryCommandType)
        {
            ResetAll();
            QueryText = queryText;
            QueryCommandType = queryCommandType;
        }


        /// <summary>
        /// Creates the Parameter
        /// </summary>
        /// <param name="name"></param>
        /// <param name="val"></param>
        /// <param name="dbType"></param>
        /// <param name="parameterDirection"></param>
        public void CreateParameter(string name, object val, DbType dbType, ParameterDirection parameterDirection = ParameterDirection.Input, int size = 0)
        {
            IDataParameter dataParameter = new SqlParameter
            {
                ParameterName = name,
                DbType = dbType
            };
            if (size > 0)
                ((SqlParameter)dataParameter).Size = size;
            if (val != null)
            {
                if (dbType == DbType.DateTime)
                    dataParameter.Value = val.ToString().ToNullablSqlDateTime();
                else
                    dataParameter.Value = val;
            }
            else
                dataParameter.Value = DBNull.Value;
            dataParameter.Direction = parameterDirection;
            AddParameter(dataParameter);
        }

        /// <summary>
        /// Creates the table parameter
        /// </summary>
        /// <param name="name"></param>
        /// <param name="val"></param>
        /// <param name="sqlDbType"></param>
        /// <param name="parameterDirection"></param>
        public void CreateTableParameter(string name, object val, SqlDbType sqlDbType, ParameterDirection parameterDirection = ParameterDirection.Input)
        {
            IDataParameter dataParameter = new SqlParameter
            {
                ParameterName = name
            };
            ((SqlParameter)dataParameter).SqlDbType = sqlDbType;

            if (val != null)
                dataParameter.Value = val;
            else
                dataParameter.Value = DBNull.Value;
            dataParameter.Direction = parameterDirection;
            AddParameter(dataParameter);
        }

        /// <summary>
        /// Adds the parameter
        /// </summary>
        /// <param name="dataParameter"></param>
        public void AddParameter(IDataParameter dataParameter)
        {
            _queryParameters.Add((SqlParameter)dataParameter);
        }

        /// <summary>
        /// Executes the Non Query- Create,Update,Delete
        /// </summary>
        public void ExecuteNonQuery()
        {
            SqlTransaction transaction = null;
            try
            {
                _dbConnection = new SqlConnection(ConnectionString);
                _dbConnection.Open();

                SqlCmd = new SqlCommand
                {
                    Connection = (SqlConnection)_dbConnection,
                    CommandText = QueryText,
                    CommandType = QueryCommandType
                };
                transaction = ((SqlConnection)_dbConnection).BeginTransaction(IsolationLevel.ReadCommitted);

                SqlCmd.Transaction = transaction;

                if (_queryParameters != null)
                {
                    foreach (SqlParameter item in _queryParameters)
                    {
                        SqlCmd.Parameters.Add(item);
                    }
                }

                SqlCmd.ExecuteNonQuery();
                transaction.Commit();
                _dbConnection.Close();

            }
            catch (Exception ex)
            {
                if (_dbConnection.State == ConnectionState.Open)
                {
                    _dbConnection.Close();
                }
                try
                {
                    transaction.Rollback();
                }
                catch (SqlException sqlex)
                {
                    if (transaction.Connection != null)
                    {
                        throw new Exception(ex.Message + " " + sqlex.Message);
                    }
                }
                throw ex;
            }
        }

        /// <summary>
        /// Executes the reader- Read
        /// </summary>
        /// <returns>void</returns>
        public IDataReader ExecuteReader()
        {
            SqlTransaction transaction = null;
            try
            {
                _dbConnection = new SqlConnection(ConnectionString);
                _dbConnection.Open();

                SqlCmd = new SqlCommand
                {
                    Connection = (SqlConnection)_dbConnection,
                    CommandText = QueryText,
                    CommandType = QueryCommandType
                };
                transaction = ((SqlConnection)_dbConnection).BeginTransaction(IsolationLevel.ReadCommitted);

                SqlCmd.Transaction = transaction;

                if (_queryParameters != null)
                {
                    foreach (SqlParameter item in _queryParameters)
                    {
                        SqlCmd.Parameters.Add(item);
                    }
                }
                IDataReader dataReader = null;
                DataSet ds = new();
                SqlDataAdapter sqlDataAdapter = new()
                {
                    SelectCommand = SqlCmd
                };
                sqlDataAdapter.Fill(ds);
                if (ds != null && ds.Tables.Count > 0)
                    dataReader = ds.CreateDataReader();

                _dbConnection.Close();
                return dataReader;
            }
            catch (Exception ex)
            {
                if (_dbConnection.State == ConnectionState.Open)
                {
                    _dbConnection.Close();
                }
                try
                {
                    transaction.Rollback();
                }
                catch (Exception sqlex)
                {
                    if (transaction.Connection != null)
                    {
                        throw new Exception(ex.Message + " " + sqlex.Message);
                    }
                }
                throw ex;
            }
        }

        /// <summary>
        /// Gets the Output Parameter
        /// </summary>
        /// <param name="name"></param>
        /// <returns>IDataParameter</returns>
        public IDataParameter GetOutputParameter(string name)
        {
            IDataParameter dataParameter = new SqlParameter();
            if (SqlCmd.Parameters.Contains(name))
            {
                dataParameter = SqlCmd.Parameters[name];
            }
            return dataParameter;
        }

        /// <summary>
        /// Gets the Debug script
        /// </summary>
        /// <returns>string</returns>
        public string GetSqlDebugScript()
        {
            //TODO:
            return string.Empty;
        }

        /// <summary>
        /// Gets the Output parameter string value
        /// </summary>
        /// <param name="value">value</param>
        /// <returns>string</returns>
        public string GetOutputParameterStringValue(string value)
        {
            IDataParameter d = GetOutputParameter(value);
            return d.Value?.ToString();
        }

        /// <summary>
        /// Gets the Output parameter Integer value
        /// </summary>
        /// <param name="value">value</param>
        /// <returns>int</returns>
        public int GetOutputParameterIntegerValue(string value)
        {
            string val = GetOutputParameter(value).Value?.ToString();
            return val.ToInteger();
        }

        /// <summary>
        /// Gets the Output parameter Integer64 value
        /// </summary>
        /// <param name="value">value</param>
        /// <returns>Integer64</returns>
        public Int64 GetOutputParameterInteger64Value(string value)
        {
            string val = GetOutputParameter(value).Value?.ToString();
            return val.ToInteger64();
        }

        /// <summary>
        /// Gets the Output parameter Decimal value
        /// </summary>
        /// <param name="value">value</param>
        /// <returns>Decimal</returns>
        public decimal GetOutputParameterDecimalValue(string value)
        {
            string val = GetOutputParameter(value).Value?.ToString();
            return val.ToDecimal();
        }

        /// <summary>
        /// Gets the Output parameter Bool value
        /// </summary>
        /// <param name="value">value</param>
        /// <returns>Bool</returns>
        public bool GetOutputParameterBoolValue(string value)
        {
            string val = GetOutputParameter(value).Value?.ToString();
            return val.ToBool();
        }

        #endregion
    }
}
