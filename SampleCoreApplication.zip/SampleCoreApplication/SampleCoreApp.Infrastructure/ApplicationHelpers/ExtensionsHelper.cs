﻿using Microsoft.AspNetCore.Mvc.Rendering;
using SampleCoreApp.Infrastructure.Base.Models;
using SampleCoreApp.Infrastructure.BaseModels;
using SampleCoreApp.Infrastructure.Constants;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using static SampleCoreApp.Infrastructure.Constants.ApplicationConstants;

namespace SampleCoreApp.Infrastructure.ApplicationHelpers
{
    public static class ExtensionsHelper
    {
        #region SelectList Helpers
        /// <summary>
        /// Converts the List to SelectList
        /// </summary>
        /// <typeparam name="T">T</typeparam>
        /// <param name="ts">List</param>
        /// <param name="dataValueField">dataValueField</param>
        /// <param name="dataTextField">dataTextField</param>
        /// <param name="selectedValues">selectedValues</param>
        /// <param name="dataGroupField">dataGroupField</param>
        /// <returns>SelectList</returns>
        public static SelectList ToSelectList<T>(this List<T> ts, string dataValueField, string dataTextField, object selectedValues = null, string dataGroupField = null)
        {
            if (ts != null)
            {
                SelectList selectLists = new(ts, dataValueField, dataTextField, selectedValues, dataGroupField);
                return selectLists;
            }
            return null;
        }
        #endregion

        #region MessageCode Helpers
        /// <summary>
        ///  Sets MessageDescription of the Model based on the message code &
        ///  For each  row in MessageModels sets MessageDescription using the combination of
        /// MessageText (description of Message code from cache) and MessageText
        /// </summary>
        /// <returns>MessageModel</returns>
        public static MessageModel SetMessageDescriptions(this MessageModel messageModel)
        {
            if (messageModel == null)
                return null;

            messageModel.SetDescriptionToModel();
            messageModel.SetDescriptionsToMessageModels();

            return messageModel;
        }

        /// <summary>
        /// Sets MessageDescription of the Model based on the message code 
        /// </summary>
        /// <returns>MessageModel</returns>
        public static MessageModel SetDescriptionToModel(this MessageModel messageModel)
        {
            if (messageModel == null)
                return null;

            //Get from cache
            Dictionary<string, MessageModel> keyValuePairs = CacheHelper.Instance.GetFromCache<Dictionary<string, MessageModel>>(CacheKeys.MessageCode) ??
                       new Dictionary<string, MessageModel>();
            if (!string.IsNullOrEmpty(messageModel.MessageCode))
            {
                if (keyValuePairs != null && keyValuePairs.TryGetValue(messageModel.MessageCode?.ToString(), out MessageModel messageModelOut))
                {
                    if (!string.IsNullOrEmpty(messageModel.MessageText))
                        messageModel.MessageDescription = $"{messageModelOut.MessageText}: {messageModel.MessageText}";
                    else
                        messageModel.MessageDescription = messageModelOut.MessageText;
                }
            }

            return messageModel;
        }


        /// <summary>
        /// For each  row in MessageModels Sets MessageDescription using the combination of
        /// MessageText (of Message code from cache) and MessageText
        /// </summary>
        /// <returns>MessageModel</returns>
        public static MessageModel SetDescriptionsToMessageModels(this MessageModel messageModel)
        {
            if (messageModel == null)
                return null;

            //Get from cache
            Dictionary<string, MessageModel> keyValuePairs = CacheHelper.Instance.GetFromCache<Dictionary<string, MessageModel>>(CacheKeys.MessageCode) ??
                       new Dictionary<string, MessageModel>();
            string msgText = "";
            if (messageModel.MessageModels != null && messageModel.MessageModels.Count > 0)
            {
                for (int i = 0; i < messageModel.MessageModels.Count; i++)
                {
                    if (keyValuePairs != null && keyValuePairs.TryGetValue(messageModel.MessageModels[i].MessageCode?.ToString(), out MessageModel messageModelOut))
                    {
                        msgText= string.IsNullOrEmpty( messageModel.MessageModels[i].MessageText)? "": $": {messageModel.MessageModels[i].MessageText}";
                        messageModel.MessageModels[i].MessageDescription = $"{messageModelOut.MessageText} {msgText}";
                    }
                }
            }
            return messageModel;
        }

        /// <summary>
        /// Gets the message model from cache using the message code
        /// </summary>
        /// <param name="messageModel"></param> 
        public static void SetMessageType(this MessageModel messageModel)
        {
            //Get from cache
            Dictionary<string, MessageModel> keyValuePairs = CacheHelper.Instance.GetFromCache<Dictionary<string, MessageModel>>(CacheKeys.MessageCode) ??
                       new Dictionary<string, MessageModel>();

            if (keyValuePairs != null && keyValuePairs.TryGetValue(messageModel.MessageCode?.ToString(), out MessageModel messageModelOut))
            {
                messageModel.MessageTypeCode = messageModelOut.MessageTypeCode;
                messageModel.MessageType = messageModelOut.MessageType;
                messageModel.MessageTypeIconClass = messageModelOut.MessageTypeIconClass;
            }

        }

        /// <summary>
        /// Gets the message model from cache using the message code
        /// </summary>
        /// <param name="messageModel"></param>
        /// <returns></returns>
        public static MessageModel GetMessageModel(this MessageModel messageModel)
        {
            if (messageModel == null)
                return null;

            //Get from cache
            Dictionary<string, MessageModel> keyValuePairs = CacheHelper.Instance.GetFromCache<Dictionary<string, MessageModel>>(CacheKeys.MessageCode) ??
                       new Dictionary<string, MessageModel>();

            if (keyValuePairs != null && keyValuePairs.TryGetValue(messageModel.MessageCode?.ToString(), out MessageModel messageModelOut))
            {
                return messageModelOut;
            }
            return messageModel;
        }
        #endregion

        #region FieldCode Helpers
        /// <summary>
        /// Adds new field code model to collection if exists in cache
        /// </summary>
        /// <param name="fieldCode"></param>
        /// <param name="pageCode"></param>
        /// <param name="fieldCodeModelSpecific"></param>
        public static List<FieldCodeModel> AddToFieldCodeModelList(this List<FieldCodeModel> fieldCodeModels, string fieldCode, string pageCode)
        {
            //Get from cache
            Dictionary<string, FieldCodeModel> keyValuePairs = CacheHelper.Instance.GetFromCache<Dictionary<string, FieldCodeModel>>(CacheKeys.FieldCode) ??
                       new Dictionary<string, FieldCodeModel>();
            AddToFieldCodeModelList(fieldCode, pageCode, keyValuePairs, ref fieldCodeModels);
            return fieldCodeModels;
        }

        /// <summary>
        /// Adds new field code model to collection
        /// </summary>
        /// <param name="fieldCode"></param>
        /// <param name="pageCode"></param>
        /// <param name="keyValuePairs"></param>
        /// <param name="fieldCodeModelSpecific"></param>
        public static void AddToFieldCodeModelList(string fieldCode, string pageCode, Dictionary<string, FieldCodeModel> keyValuePairs, ref List<FieldCodeModel> fieldCodeModels)
        {
            fieldCodeModels ??= new List<FieldCodeModel>();

            if (keyValuePairs != null && keyValuePairs.TryGetValue($"{fieldCode}{ApplicationConstants.FieldCodePageCodeSeparator}{pageCode}", out FieldCodeModel fieldCodeModel))
            {
                try
                {
                    fieldCodeModels.Add(fieldCodeModel);
                }
                catch (Exception)
                {
                }
            }
        }

        /// <summary>
        /// Gets the fieldcode model from cache using the field code
        /// </summary>
        /// <param name="fieldCodeModel"></param>
        /// <returns></returns>
        public static FieldCodeModel GetFieldCodeModel(this FieldCodeModel fieldCodeModel)
        {
            if (fieldCodeModel == null)
                return null;

            //Get from cache
            Dictionary<string, FieldCodeModel> keyValuePairs = CacheHelper.Instance.GetFromCache<Dictionary<string, FieldCodeModel>>(CacheKeys.FieldCode) ??
                       new Dictionary<string, FieldCodeModel>();

            if (keyValuePairs != null && keyValuePairs.TryGetValue(fieldCodeModel.FieldCode?.ToString(), out FieldCodeModel fieldCodeModelOut))
            {
                return fieldCodeModelOut;
            }
            return fieldCodeModel;
        }

        /// <summary>
        /// Gets the fieldcode model from cache using the field code
        /// </summary>
        /// <param name="fieldCodeModel"></param>
        /// <returns></returns>
        public static List<FieldValueModel> GetFieldValuesModel(this FieldCodeModel fieldCodeModel)
        {
            if (fieldCodeModel == null)
                return null;

            //Get from cache
            List<FieldValueModel> lst = CacheHelper.Instance.GetFromCache<List<FieldValueModel>>(CacheKeys.FieldValues) ??
                       new List<FieldValueModel>();

            if (lst != null)
            {
                return lst.Where(l=>l.FieldCode==fieldCodeModel.FieldCode).ToList();
            }
            return null;
        }
        #endregion
    }
}
