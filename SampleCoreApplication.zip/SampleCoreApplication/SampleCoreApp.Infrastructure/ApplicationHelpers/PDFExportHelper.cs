﻿using SampleCoreApp.Infrastructure.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.ApplicationHelpers
{
    public class PDFExportHelper : IPDFExportHelper
    {
        /// <summary>
        /// Exports the Data
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dataSource">DataSource</param>
        /// <param name="exportFileName">ExportFileName</param>
        /// <param name="configDataSource">Configuration DataSource</param>
        /// <param name="hasfileNameDateTime">HasfileNameDateTime</param>
        /// <param name="temporaryFolderPath">TemporaryFolderPath</param>
        public void Export<T>(T dataSource, string exportFileName, T configDataSource, bool hasfileNameDateTime = false, string temporaryFolderPath = "")
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Exports the Data
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dataSource">DataSource</param> 
        /// <param name="exportFileName">ExportFileName</param>
        /// <param name="configDataSource">Configuration DataSource</param>
        /// <param name="hasfileNameDateTime">HasfileNameDateTime</param>
        /// <param name="temporaryFolderPath">TemporaryFolderPath</param>
        /// <param name="templateFileName">TemplateFileName</param>
        /// <param name="templateFilePath">TemplateFilePath</param>
        public void Export<T>(T dataSource, string exportFileName, T configDataSource, bool hasfileNameDateTime = false, string temporaryFolderPath = "", string templateFileName = "", string templateFilePath = "")
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Exports the Data
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dataSource">DataSource</param>
        /// <param name="exportFileName">ExportFileName</param>
        /// <param name="configDataSource">Configuration DataSource</param>
        /// <param name="hasfileNameDateTime">HasfileNameDateTime</param>
        /// <param name="temporaryFolderPath">TemporaryFolderPath</param>
        /// <param name="templateFullFileNamePath">templateFullFileNamePath</param>
        public void Export<T>(T dataSource, string exportFileName, T configDataSource, bool hasfileNameDateTime = false, string temporaryFolderPath = "", string templateFullFileNamePath = "")
        {
            throw new NotImplementedException();
        }
    }
}
