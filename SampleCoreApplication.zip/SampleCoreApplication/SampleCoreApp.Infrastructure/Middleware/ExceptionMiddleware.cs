﻿using Microsoft.AspNetCore.Http; 
using System;
using System.Collections.Generic;
using System.Net; 
using System.Threading.Tasks;

using SampleCoreApp.Infrastructure.BaseModels;
using SampleCoreApp.Infrastructure.Constants;
using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Infrastructure.ApplicationHelpers;

namespace SampleCoreApp.Infrastructure.Middleware
{
    public class ExceptionMiddleware
    {
        private readonly RequestDelegate _next; 

        public ExceptionMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext httpContext)
        {
            try
            {
                await _next(httpContext);
            }
            catch (Exception ex)
            {
                await HandleGlobalExceptionAsync(httpContext, ex);
            }
        }

        private static Task HandleGlobalExceptionAsync(HttpContext context, Exception exception)
        {
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;

            //Set the message model
            MessageModel messageModel = new (); 
            messageModel.MessageCode = context.Response.StatusCode.ToString();
            messageModel.MessageText = ApplicationConstants.ExceptionMessage;
            if (BaseApplicationAppSettings.ShowExceptionDetails)
            {
                List<MessageModel> messageModels = new ();
                MessageModel mexceptionDetails = new ();
                mexceptionDetails.MessageText = exception.Message;
                mexceptionDetails.MessageDescription = exception.StackTrace;
                messageModels.Add(mexceptionDetails);
                messageModel.MessageModels = messageModels;
            } 

            //Ajax Request->Headers["X-Requested-With"] == "XMLHttpRequest" 
            if (AppSettings.IsModelOnly ||( context.Request.Headers["X-Requested-With"].Count > 0
                && context.Request.Headers["X-Requested-With"][0].ToLower() == "XMLHttpRequest".ToLower()))
            {
                return context.Response.WriteAsync(messageModel.ToJson());
            }
            else //if not Ajax request - redirect to error view
            {  
                context.Session.Set(ApplicationConstants.ExceptionDetailSessionsKey, exception);
                context.Response.Redirect($"{context.Request.PathBase}{ApplicationConstants.ErrorView}");
                return Task.CompletedTask; 
            }
        }
        
    }
}

