﻿using SampleCoreApp.Infrastructure.Base.Models;
using SampleCoreApp.Infrastructure.BaseModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Interfaces
{
    public interface IGenericUnitOfWork
    {
        List<TransactionModel> GetTransactionsModel();

        List<FieldCodeModel> GetFieldCodeModels();
    }
}
