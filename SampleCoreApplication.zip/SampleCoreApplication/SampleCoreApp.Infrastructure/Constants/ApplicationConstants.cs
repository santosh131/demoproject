﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Constants
{
    public sealed class ApplicationConstants
    { 
        public static readonly string ExceptionMessage = "Something went wrong !Internal Server Error";
        public static readonly string ErrorView = "/Home/Error";
        public static readonly string ConnectionStringKey = "Default";
        public static readonly string ShowExceptionDetailsKey = "ShowExceptionDetails";
        public static readonly string ExceptionDetailSessionsKey = "ShowExceptionDetailsSession";
        public static readonly string FieldCodePageCodeSeparator = "-";

        public static class CacheKeys
        {
            public static readonly string FieldCode= "FieldCode";
            public static readonly string FieldValues = "FieldValues";
            public static readonly string MessageCode= "MessageCode";
            public static readonly string Menus = "Menus";
        }

        public static class SampleTypes
        {
            public static readonly string None = "";
            public static readonly string Option1 = "";
        } 
    } 
}
