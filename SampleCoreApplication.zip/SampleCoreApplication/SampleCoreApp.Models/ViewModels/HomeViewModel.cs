﻿using SampleCoreApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SampleCoreApp.Models.Models.SampleModuleModel;
using SampleCoreApp.Models.Models;
using SampleCoreApp.Infrastructure.BaseModels;

namespace SampleCoreApp.Models.ViewModels
{
    [Serializable]
    public class HomeViewModel : BaseViewModel
    {
        public List<HomeModel> HomeModels { get; set; }

        public HomeModel HomeModel { get; set; }

        public List<DepartmentModel> SampleDropdownLookupModel { get; set; } 
    }
}
