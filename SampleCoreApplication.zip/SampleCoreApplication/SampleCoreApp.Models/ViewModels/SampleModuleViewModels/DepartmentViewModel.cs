﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Text;

using SampleCoreApp.Infrastructure.BaseModels;
using SampleCoreApp.Models.Models.SampleModuleModel;

namespace SampleCoreApp.Models.ViewModels.SampleModuleViewModels
{
    [Serializable]
    public class DepartmentViewModel : BaseViewModel
    {
        public List<DepartmentModel> DepartmentModels { get; set; }

        public DepartmentModel DepartmentModel { get; set; } 

    }
}
