﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Models.Constants
{
    public static class TableTypeHelpers
    {
    }
}
