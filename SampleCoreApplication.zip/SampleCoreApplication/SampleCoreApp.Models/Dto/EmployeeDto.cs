﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Text;
using SampleCoreApp.Infrastructure.BaseModels;
using SampleCoreApp.Models.Models.SampleModuleModel;
using SampleCoreApp.Infrastructure.Base.Models;

namespace SampleCoreApp.Models.Dto
{
    [Serializable]
    public class EmployeeDto : BaseDto
    {
        public List<EmployeeModel> EmployeeModels { get; set; }

        public EmployeeModel EmployeeModel { get; set; }
    }
}
