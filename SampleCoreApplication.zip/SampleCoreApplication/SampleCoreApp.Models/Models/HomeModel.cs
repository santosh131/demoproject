﻿using System;
using SampleCoreApp.Infrastructure.Base.Models;

namespace SampleCoreApp.Models.Models
{
    [Serializable]
    public class HomeModel:BaseModel
    {
        public string Message { get; set; }
    }
}
