﻿using SampleCoreApp.Infrastructure.Base.Models;
using SampleCoreApp.Infrastructure.BaseModels;
using SampleCoreApp.Infrastructure.Interfaces;
using SampleCoreApp.Interfaces.Repositories;

namespace SampleCoreApp.Interfaces.UnitOfWork
{
    public interface ILookupUnitOfWork : IGenericUnitOfWork
    {
        ILookupRepository GetLookupRepository();

        FieldCodeModel GetFieldCodeModel(string fieldCode, string pageCode);
        MessageModel GetMessageModel(string messageCode);
    }
}
