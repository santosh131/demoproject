﻿using SampleCoreApp.Infrastructure.Interfaces;
using SampleCoreApp.Interfaces.Repositories;

namespace SampleCoreApp.Interfaces.UnitOfWork
{
    public interface IHomeUnitOfWork: IGenericUnitOfWork
    {
        IHomeRepository GetHomeRepository();

        ILookupRepository GetLookupRepository();
    }
}
