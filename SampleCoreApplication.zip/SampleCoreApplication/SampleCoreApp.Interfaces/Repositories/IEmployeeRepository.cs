﻿using SampleCoreApp.Infrastructure.Base.Interfaces;
using SampleCoreApp.Infrastructure.Base.Models;
using SampleCoreApp.Infrastructure.BaseModels;
using SampleCoreApp.Models.Models.SampleModuleModel;

namespace SampleCoreApp.Interfaces.Repositories
{
    public interface IEmployeeRepository : 
        IGenericReadAllSaveRepository<EmployeeModel, CommonModel,MessageModel, SortingPagingModel> ,
        IGenericReadSingleRepository<EmployeeModel, CommonModel, MessageModel, SortingPagingModel>
    { 

    }
}
