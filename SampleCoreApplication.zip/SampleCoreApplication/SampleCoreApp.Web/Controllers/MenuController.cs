﻿using Microsoft.AspNetCore.Mvc;
using SampleCoreApp.Infrastructure.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.Constants;
using SampleCoreApp.Infrastructure.BaseModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleCoreApp.Web.Controllers
{
    public class MenuController : BaseController
    {
        public IActionResult Index()
        {
            MenuViewModel menuViewModel = new();
            List<MenuModel> menuModels = new();
            MessageModel messageModel = new();
            MenuModel menuModel = new();
            MenuModel childMenuModel = new();
            MenuModel subchildMenuModel = new();
            MenuModel subchildMenuModel2 = new();
            menuViewModel.ApplicationName = AppSettings.ApplicationName; 

            try
            {
                //---------
                menuModel.MenuId = "1001";
                menuModel.MenuName = "Home";
                menuModel.MenuControllerName = "Home";
                menuModel.MenuActionName = "Index";
                menuModels.Add(menuModel);

                //---------
                menuModel = new();
                menuModel.MenuId = "1002";
                menuModel.MenuName = "Privacy Menu";

                menuModel.ChilMenus = new();
                childMenuModel = new();
                childMenuModel.ParentMenuId = "1002";
                childMenuModel.MenuId = "C1002";                
                childMenuModel.MenuName = "Privacy child 1";
                childMenuModel.MenuControllerName = "Home";
                childMenuModel.MenuActionName = "Privacy";
                childMenuModel.IsChildMenu = true;
                menuModel.ChilMenus.Add(childMenuModel);

                childMenuModel = new();
                childMenuModel.ParentMenuId = "1002";
                childMenuModel.MenuId = "C1003";                
                childMenuModel.MenuName = "Privacy Child 2";
                childMenuModel.MenuControllerName = "Home";
                childMenuModel.MenuActionName = "Privacy";
                childMenuModel.IsChildMenu = true;

                childMenuModel.ChilMenus = new();

                subchildMenuModel = new();
                subchildMenuModel.ParentMenuId = "C1002";
                subchildMenuModel.MenuId = "CC1002";
                subchildMenuModel.MenuName = "Privacy Sub Child 1";
                subchildMenuModel2.MenuControllerName = "Home";
                subchildMenuModel2.MenuActionName = "Privacy";
                subchildMenuModel.IsChildMenu = true;

                subchildMenuModel2 = new();
                subchildMenuModel2.ParentMenuId = "C10021";
                subchildMenuModel2.MenuId = "CC10021";
                subchildMenuModel2.MenuName = "Privacy Sub Child 1 1";
                subchildMenuModel2.MenuControllerName = "Home";
                subchildMenuModel2.MenuActionName = "Privacy";
                subchildMenuModel2.IsChildMenu = true;
                subchildMenuModel.ChilMenus = new();
                subchildMenuModel.ChilMenus.Add(subchildMenuModel2);

                childMenuModel.ChilMenus.Add(subchildMenuModel);

                menuModel.ChilMenus.Add(childMenuModel);

                menuModels.Add(menuModel);
                //---------

                menuModel = new();
                menuModel.MenuId = "1003";
                menuModel.MenuName = "Demo Screens";
                menuModel.MenuControllerName= "";
                menuModel.MenuActionName= "";
                menuModel.ChilMenus = new();

                childMenuModel = new();
                childMenuModel.ParentMenuId = "1003";
                childMenuModel.MenuId = "C1003";
                childMenuModel.MenuName = "Employee";
                childMenuModel.MenuControllerName = "Employee";
                childMenuModel.MenuActionName = "Index";
                childMenuModel.IsChildMenu = true;
                
                menuModel.ChilMenus.Add(childMenuModel);

                menuModels.Add(menuModel);
                //---------
                messageModel.MessageTypeCode = MessageTypeCodeConstants.Success;
            }
            catch (Exception ex)
            {
                messageModel.MessageTypeCode = MessageTypeCodeConstants.SystemError;
                messageModel.MessageText = ex.Message;
                messageModel.MessageDescription= ex.StackTrace;
            }
            menuViewModel.MenuModels = menuModels;
            menuViewModel.AdditionalInfoViewModel.MessageModel= messageModel;

            return RenderViewsJson(nameof(Index), menuViewModel, false,true);
        }
    }
}
