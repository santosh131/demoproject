﻿using Microsoft.AspNetCore.Mvc;
using SampleCoreApp.Infrastructure.Base.Models;
using SampleCoreApp.Interfaces.UnitOfWork;
using SampleCoreApp.Models;
using SampleCoreApp.Infrastructure.BaseModels;
using SampleCoreApp.Models.Models.SampleModuleModel;
using SampleCoreApp.Models.Models;
using SampleCoreApp.Models.ViewModels;
using SampleCoreApp.Web.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Microsoft.Extensions.Configuration;
using SampleCoreApp.Infrastructure.Constants;
using Microsoft.AspNetCore.Http;
using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.Constants;

namespace SampleCoreApp.Web.Controllers
{
    public class HomeController : BaseController
    {
        private readonly IHomeUnitOfWork _homeUnitOfWork;

        public HomeController(IHomeUnitOfWork repository)
        {
            _homeUnitOfWork = repository;
        }

        public IActionResult HomeRedirected()
        {
            //HomeModel homeModel = new();
            //HomeViewModel homeViewModels = new();
            //MessageModel messageModel = new();
            //CommonModel commonModel = new();
            //SortingPagingModel sortingPagingModel = new();

            //homeViewModels.HomeModels = _homeUnitOfWork.GetHomeRepository().GetAll(homeModel, commonModel, ref messageModel, ref sortingPagingModel).ToList();
            //homeViewModels.SampleDropdownLookupModel = _homeUnitOfWork.GetLookupRepository().GetDepartmentDropdownLookup(new DepartmentModel(), ref commonModel, ref messageModel).ToList();
            //homeViewModels.TransactionsModel = _homeUnitOfWork.GetTransactionsModel();
            //homeViewModels.MessageModel = messageModel;
            //if (HttpContext.Request.Headers["X-Requested-With"].Count > 0
            //   && HttpContext.Request.Headers["X-Requested-With"][0].ToLower() == "XMLHttpRequest".ToLower())
            //{
            //    return RenderViewsJson(nameof(Index), homeViewModels, true);
            //}
            return View(nameof(HomeRedirected));
        }

        public IActionResult Index()
        {
            HomeModel homeModel = new();
            HomeViewModel homeViewModels = new();
            MessageModel messageModel = new();
            CommonModel commonModel = new();
            SortingPagingModel sortingPagingModel = new();

            homeViewModels.HomeModels = _homeUnitOfWork.GetHomeRepository().GetAll(homeModel, commonModel, ref messageModel, ref sortingPagingModel).ToList();
            homeViewModels.SampleDropdownLookupModel = _homeUnitOfWork.GetLookupRepository().GetDepartmentDropdownLookup(new DepartmentModel(), ref commonModel, ref messageModel).ToList();
            homeViewModels.AdditionalInfoViewModel.TransactionsModel = _homeUnitOfWork.GetTransactionsModel();
            homeViewModels.AdditionalInfoViewModel.MessageModel = messageModel;
            return RenderViewsJson(nameof(Index), homeViewModels, true,false);
            //if (HttpContext.Request.Headers["X-Requested-With"].Count > 0
            //   && HttpContext.Request.Headers["X-Requested-With"][0].ToLower() == "XMLHttpRequest".ToLower())
            //{
            //    return RenderViewsJson(nameof(Index), homeViewModels, true);
            //}
            //return View(homeViewModels);
        }

        public IActionResult Privacy()
        {
            return RenderViewsJson(nameof(Privacy), null, true,false);
        }

        //[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            ErrorViewModel errorViewModel = new();
            MessageModel messageModel = new()
            {
                MessageTypeCode = MessageTypeCodeConstants.SystemError,
                MessageCode = HttpContext.Response.StatusCode.ToString(),
                MessageText = ApplicationConstants.ExceptionMessage
            };

            if (BaseApplicationAppSettings.ShowExceptionDetails)
            {
                var exception = HttpContext.Session.Get<Exception>(ApplicationConstants.ExceptionDetailSessionsKey);
                List<MessageModel> messageModels = new();
                MessageModel mexceptionDetails = new()
                {
                    MessageText = exception.Message,
                    MessageDescription = exception.StackTrace
                };
                messageModels.Add(mexceptionDetails);
                messageModel.MessageModels = messageModels;
            }

            errorViewModel.RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier;
            errorViewModel.AdditionalInfoModel = new();
            errorViewModel.AdditionalInfoModel.MessageModel = messageModel;
            return View(errorViewModel);
        }
    }
}
