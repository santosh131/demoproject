﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Constants;
using SampleCoreApp.Infrastructure.ApplicationHelpers;

namespace SampleCoreApp.Web.Infrastructure
{
    public static class RegisterAppSettings
    { 
        public static void SetAppSettings(ref IServiceCollection services, IConfiguration configuration)
        {
            BaseApplicationAppSettings.ConnectionString= configuration.GetConnectionString(ApplicationConstants.ConnectionStringKey);            
            BaseApplicationAppSettings.ShowExceptionDetails = configuration.GetValue<string>(ApplicationConstants.ShowExceptionDetailsKey).ToBool();

            AppSettings.KeyPhrase = configuration.GetValue<string>("Security:Keyphrase");
            AppSettings.ApplicationName = configuration.GetValue<string>("ApplicationName");
            AppSettings.IsModelOnly = configuration.GetValue<string>("IsModelOnly").ToBool(); 
            
        }
    }
}
