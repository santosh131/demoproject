﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SampleCoreApp.Infrastructure.Base.Constants;
using SampleCoreApp.Infrastructure.Base.Models;
using SampleCoreApp.Interfaces.UnitOfWork;
using SampleCoreApp.Models.Models.SampleModuleModel;
using SampleCoreApp.Models.ViewModels.SampleModuleViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SampleCoreApp.Infrastructure.ApplicationHelpers;
using SampleCoreApp.Infrastructure.BaseModels;
using System.Net.Http;
using System.Net.Http.Json;
using System.Net;
using SampleCoreApp.Web.Models;
using System.Net.Mime;
using SampleCoreApp.Models.Dto;

namespace SampleCoreApp.Web.api
{
    [Route("api/[controller]")]
    
    public class EmployeeApiController : BaseApiController
    {
        private readonly IEmployeeUnitOfWork _employeeUnitOfWork;
        public EmployeeApiController(IEmployeeUnitOfWork employeeUnitOfWork)
        {
            _employeeUnitOfWork = employeeUnitOfWork;
        }

        [HttpGet]
        [Route("GetTransactions")]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult<List<TransactionModel>>> GetTransactions()
        {
            var models= await Task.Run(()=> { return _employeeUnitOfWork.GetTransactionsModel(); });
            if (models == null)
                return NotFound(new MessageModel() { MessageCode = "1001", MessageDescription = "No Records Found", MessageType = "E" });
            return Ok(models);             
        }

        [HttpGet]
        [Route("GetFieldCodes")]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult<List<FieldCodeModel>>> GetFieldCodes()
        {
            var models = await Task.Run(() => { return _employeeUnitOfWork.GetFieldCodeModels(); });
            if (models == null)
                return NotFound(new MessageModel() { MessageCode = "1001", MessageDescription = "No Records Found", MessageType = "E" });
            return Ok(models);
        }


        [HttpGet]
        [Route("GetFieldCodesAndTransactionCodes")]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult<List<AdditionalInfoViewModel>>> GetFieldCodesAndTransactionCodes()
        {
            var tranModels = await Task.Run(() => { return _employeeUnitOfWork.GetTransactionsModel(); });
            var fieldmodels = await Task.Run(() => { return _employeeUnitOfWork.GetFieldCodeModels(); });
            if (tranModels == null && fieldmodels==null)
                return NotFound(new MessageModel() { MessageCode = "1001", MessageDescription = "No Records Found", MessageType = "E" });                        
            return Ok(new AdditionalInfoViewModel() { FieldCodeModels = fieldmodels, TransactionsModel = tranModels });
        }

        [HttpGet]
        [Route("GetEmployees")]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult<EmployeeDto> GetEmployees([FromQuery]EmployeeModel employeeModel,[FromQuery]SortingPagingModel sortingPagingModel2)
        {
            employeeModel ??= new();
            SortingPagingModel sortingPagingModel= sortingPagingModel2;            
            EmployeeDto employeeDto = new();
            CommonModel commonModel = new();
            MessageModel messageModel = new();

            sortingPagingModel.ItemsPerPage = 5;
            commonModel.ActionCode = CRUDOperationsConstants.List;

            employeeDto.EmployeeModels = _employeeUnitOfWork.GetEmployeeRepository().GetAll(employeeModel, commonModel, ref messageModel, ref sortingPagingModel);
            employeeDto.AdditionalInfoModel.SortingPagingModel = sortingPagingModel;
            employeeDto.AdditionalInfoModel.SortingPagingModel.TotalItems = employeeDto.EmployeeModels.Count;
            if(employeeDto.EmployeeModels==null || employeeDto.EmployeeModels.Count == 0)
            {
                //return NoContent();
                return NotFound(new MessageModel() { MessageCode = "1001", MessageDescription = "No Records Found", MessageType = "E" });
            }
            return Ok(employeeDto);
        }
    }
}
