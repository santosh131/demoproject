﻿using Microsoft.AspNetCore.Mvc;
using SampleCoreApp.Infrastructure.Base.Constants;
using SampleCoreApp.Infrastructure.Base.Models;
using SampleCoreApp.Infrastructure.BaseModels;
using SampleCoreApp.Interfaces.UnitOfWork;
using SampleCoreApp.Models.Models.SampleModuleModel;
using SampleCoreApp.Models.ViewModels.SampleModuleViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SampleCoreApp.Infrastructure.Base.Static;
using Microsoft.AspNetCore.Http;
using SampleCoreApp.Web.Controllers;
using Microsoft.EntityFrameworkCore.ChangeTracking.Internal;
using SampleCoreApp.Infrastructure.ApplicationHelpers;

namespace SampleCoreApp.Web.Areas.Popup.Controllers
{
    public class DepartmentController : BaseController
    {
        private readonly IDepartmentUnitOfWork _departmentUnitOfWork;
        public DepartmentController(IDepartmentUnitOfWork departmentUnitOfWork)
        {
            _departmentUnitOfWork = departmentUnitOfWork;
        }

        // GET: Department
        [HttpGet]
        public ActionResult Index(DepartmentModel departmentModel, SortingPagingModel sortingPagingModel)
        {
            departmentModel ??= new DepartmentModel();
            sortingPagingModel ??= new SortingPagingModel();

            DepartmentViewModel departmentViewModel = new();
            CommonModel commonModel = new();
            MessageModel messageModel = new();

            commonModel.ActionCode = CRUDOperationsConstants.SelectList;
            sortingPagingModel.ItemsPerPage = 5;

            commonModel.ActionCode = CRUDOperationsConstants.Popup;
            departmentViewModel.DepartmentModel = departmentModel;
            departmentViewModel.DepartmentModels = _departmentUnitOfWork.GetDepartmentRepository().GetAll(departmentModel, commonModel, ref messageModel, ref sortingPagingModel);
            departmentViewModel.AdditionalInfoViewModel.TransactionsModel = _departmentUnitOfWork.GetTransactionsModel();
            departmentViewModel.AdditionalInfoViewModel.MessageModel = messageModel.SetMessageDescriptions();
            departmentViewModel.AdditionalInfoViewModel.SortingPagingModel = sortingPagingModel;
            departmentViewModel.AdditionalInfoViewModel.SortingPagingModel.TotalItems = departmentViewModel.DepartmentModels.Count;
            //return View(departmentViewModel);
            //return Json(new { PartialView = departmentViewModel });
            return RenderViewsJson(nameof(Index), departmentViewModel, true);
        }

        [HttpGet]
        public ActionResult SearchGrid(DepartmentModel departmentModel, SortingPagingModel sortingPagingModel)
        {
            departmentModel ??= new();
            sortingPagingModel ??= new();

            DepartmentViewModel departmentViewModel = new();
            CommonModel commonModel = new();
            MessageModel messageModel = new(true);

            commonModel.ActionCode = CRUDOperationsConstants.Popup;
            sortingPagingModel.ItemsPerPage = 5;

            departmentViewModel.DepartmentModel = departmentModel;
            departmentViewModel.DepartmentModels = _departmentUnitOfWork.GetDepartmentRepository().GetAll(departmentModel, commonModel, ref messageModel, ref sortingPagingModel);            
            departmentViewModel.AdditionalInfoViewModel.MessageModel = messageModel.SetMessageDescriptions();
            departmentViewModel.AdditionalInfoViewModel.SortingPagingModel = sortingPagingModel;
            departmentViewModel.AdditionalInfoViewModel.SortingPagingModel.TotalItems = departmentViewModel.DepartmentModels.Count;
            //return PartialView(departmentViewModel);
            //return Json(new { PartialView = departmentViewModel });
            return RenderViewsJson(nameof(SearchGrid), departmentViewModel, true);
        }
    }
}
