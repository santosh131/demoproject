using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;

using SampleCoreApp.Web.Infrastructure;
using Microsoft.Extensions.Hosting;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.Authentication.Cookies;
using SampleCoreApp.UnitOfWork.StartupHelpers;
using SampleCoreApp.Infrastructure.ApplicationHelpers;
/*
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Infrastructure.BaseModels;
using SampleCoreApp.Infrastructure.Constants;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
*/

namespace SampleCoreApp.Web
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDistributedMemoryCache();

            services.AddSession(options =>
            {
                options.IdleTimeout = TimeSpan.FromSeconds(10); //TODO:
                options.Cookie.HttpOnly = true;
                options.Cookie.IsEssential = true;
            });

            services.AddControllersWithViews();

            //Configure ASP.NET Core to work with proxy servers and load balancers
            services.Configure<ForwardedHeadersOptions>(options =>
            {
                options.ForwardedHeaders =
                    ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
            });

            services.AddRazorPages();
            services.AddControllers(options =>
            {
                options.RespectBrowserAcceptHeader = true; // false by default
            }).AddJsonOptions(jsonOptions =>
            {
                jsonOptions.JsonSerializerOptions.PropertyNamingPolicy = null;
            }); //AddJsonOptions --JSON properties are sent as camelCase from controller,
                //this setting will preserve the naming of properties while converting the model to json

            RegisterAppSettings.SetAppSettings(ref services, Configuration);

            //To support in-memory caching
            services.AddMemoryCache();
             
            RegisterStartupHelper.RegisterServices(ref services);
            services.AddSwaggerGen();

            //Add Authorize attribute on controllers other than login
            //Authenticate Microsoft,Google account
            //services.AddAuthentication() //or 
           // services.AddAuthentication(options =>
           // {
           //     options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
           // })
           // .AddCookie(CookieAuthenticationDefaults.AuthenticationScheme, options =>
           //     {
           //         options.AccessDeniedPath = "/account/denied";
           //         options.LoginPath = "/account/login";
           // })
           //.AddCookie(options =>
           //{
           //    options.LoginPath = "/account/google-login"; // Must be lowercase , here we can add microsoft
           //})
           //.AddMicrosoftAccount(options =>
           //{
           //    options.ClientId = Configuration["Authentication:Microsoft:ClientId"];
           //    options.ClientSecret = Configuration["Authentication:Microsoft:ClientSecret"];
           //})
           //.AddGoogle(options =>
           //{
           //    options.ClientId = Configuration["Authentication:Google:ClientId"];
           //    options.ClientSecret = Configuration["Authentication:Google:ClientSecret"];
           //});            
        }
        



        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, CacheStartupService cacheStartupService)
        {
            //Added session here - Helps to keep the error information in session
            app.UseSession();
            cacheStartupService.SetCache();

            if (env.IsDevelopment())
            {
                //Exception Handling middleware
                app.UseGlobalExceptionMiddleware();
                //app.UseDeveloperExceptionPage();

                //Run app in multiple application
                //app.UseBrowserLink();

                //Forwarded Headers Middleware: Configure ASP.NET Core to work with proxy servers and load balancers
                app.UseForwardedHeaders();
            }
            else
            {
                //Exception Handling middleware
                app.UseGlobalExceptionMiddleware();

                //Forwarded Headers Middleware: Configure ASP.NET Core to work with proxy servers and load balancers
                //UseForwardedHeaders should be called UseHsts
                app.UseForwardedHeaders();

                //HTTP Strict Transport Security Protocol, The default HSTS value is 30 days
                app.UseHsts();

            }

            //HTTPS Redirection Middleware
            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            //Authentication : AddAuthentication().AddMicrosoftAccount/AddGoogle is added 
            // Must be before UseEndPoints
            //app.UseAuthentication(); //TODO: uncomment if authentication is enabled
            app.UseAuthorization();

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("../swagger/v1/swagger.json", "SampleCoreApp");
            });
            
            //app.UseSession();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapAreaControllerRoute(
                  name: "areas",
                  areaName: "Popup",
                  pattern: "popup/{controller=Home}/{action=Index}/{id?}"
                );

                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
