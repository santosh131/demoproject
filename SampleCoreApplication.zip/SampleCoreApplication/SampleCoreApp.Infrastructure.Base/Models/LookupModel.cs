﻿using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Models
{
    [Serializable]
    public class LookupModel: BaseLookupModel
    {
        [DbColumnName("code")]
        public string Code { get; set; }

        [DbColumnName("desc_txt")]
        public string Description { get; set; }

        [DbColumnName("code_desc_txt")]
        public string CodeDescription { get; set; }
    }
}
