﻿using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Models
{
    public class FieldValueModel : ModelHelper
    {
        [DbColumnName("field_cd")]
        public string FieldCode { get; set; }

        [DbColumnName("value_cd")]
        public string ValueCode { get; set; }

        [DbColumnName("desc_txt")]
        public string Description { get; set; }

        [DbColumnName("order_nbr")]
        public int OrderNbr { get; set; }

        [DbColumnName("active_ind")]
        public bool ActiveInd { get; set; }
    }
}
