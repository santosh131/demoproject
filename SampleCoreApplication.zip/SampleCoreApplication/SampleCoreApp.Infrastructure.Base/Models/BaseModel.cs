﻿using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Models
{
    [Serializable]
    public abstract class BaseModel : ModelHelper
    {
        private string _recordMode = string.Empty;
        private int? _recordIndex;

        public string RecordMode { get => _recordMode; set => _recordMode = value; }
        public int? RecordIndex { get => _recordIndex; set => _recordIndex = value; }
    }
}
