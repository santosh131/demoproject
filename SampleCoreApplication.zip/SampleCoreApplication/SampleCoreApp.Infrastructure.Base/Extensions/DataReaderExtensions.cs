﻿using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Extensions
{
    public static class DataReaderExtensionHelper
    {
        /// <summary>
        /// Converts the datareader to collection
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dataReader">IDataReader</param>
        /// <param name="fromDbColumn">FromDbColumn</param>
        /// <returns>List<T></returns>
        public static List<T> ToCollection<T>(this IDataReader dataReader, bool fromDbColumn = true)
        {
            List<T> list = new();
            if (dataReader != null)
            {
                T obj1 = Activator.CreateInstance<T>();
                string dbcolName;
                PropertyInfo[] propertyInfos = obj1.GetType().GetProperties();

                Dictionary<string, string> dicKeyValues = new();
                for (int i = 0; i < propertyInfos.Length; i++)
                {
                    dicKeyValues.Add(propertyInfos[i].Name, AttributesHelper.GetDbColumnAttributeVal(propertyInfos[i]));
                }

                while (dataReader.Read())
                {
                    T obj = Activator.CreateInstance<T>();
                    foreach (PropertyInfo prop in propertyInfos)
                    {
                        dbcolName = prop.Name;

                        if (fromDbColumn)
                        {
                            dicKeyValues.TryGetValue(prop.Name, out dbcolName);
                        }
                           //dbcolName = AttributesHelper.GetDbColumnAttributeVal(prop);

                        if (dataReader.HasColumn(dbcolName) && !object.Equals(dataReader[dbcolName], DBNull.Value))
                        {
                            prop.SetValue(obj, dataReader[dbcolName], null);
                        }
                    }
                    list.Add(obj);
                }
            }
            return list;
        }

        /// <summary>
        /// Converts the datareader to collection using the Fill method by default
        /// </summary>
        /// <typeparam name="T">T</typeparam>
        /// <param name="dr">IDataReader</param>
        /// <param name="methodName">MethodName</param>
        /// <param name="fromDbColumn">FromDbColumn</param>
        /// <param name="isClosed">IsClosed</param>
        /// <returns></returns>
        public static List<T> ToCollectionUsingMethod<T>(this IDataReader dr, string methodName = "FillUsingPropInfo", bool fromDbColumn = true, bool isClosed = true)
        {
            List<T> lst = Activator.CreateInstance<List<T>>();
            T t1 = Activator.CreateInstance<T>();
            MethodInfo methodInfo = t1.GetType().GetMethod(methodName, BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
            ParameterInfo[] parameters = methodInfo.GetParameters();

            PropertyInfo[] pInfo = t1.GetType().GetProperties();
            Dictionary<string, string> kedicKeyValues = new();
            for (int i = 0; i < pInfo.Length; i++)
            {
                kedicKeyValues.Add(pInfo[i].Name, AttributesHelper.GetDbColumnAttributeVal(pInfo[i]));
            }

            if (dr != null)
            {
                while (dr.Read())
                {
                    T t = Activator.CreateInstance<T>();
                    dynamic result;
                    if (parameters.Length == 0)
                    {
                        result = methodInfo.Invoke(t, null);
                        lst.Add(result);
                    }
                    else
                    { 
                        if (methodName == "Fill")
                        {
                            object[] parametersArray = new object[] { dr, fromDbColumn };
                            result = methodInfo.Invoke(t, parametersArray);
                            lst.Add(result);
                        }
                        else if (methodName == "FillUsingPropInfo")
                        {
                            object[] parametersArray = new object[] { dr, pInfo, kedicKeyValues, fromDbColumn };
                            result = methodInfo.Invoke(t, parametersArray);
                            lst.Add(result);
                        }
                    }
                }
                if (isClosed)
                {
                    if (!dr.IsClosed)
                        dr.Close();
                }
            }
            return lst;
        }

        /// <summary>
        /// Converts the datareader to DataTable
        /// </summary>
        /// <param name="dataReader">IDataReader</param>
        /// <returns>DataTable</returns>
        public static DataTable ToDataTable(this IDataReader dataReader)
        {
            DataTable dataTable = new();
            DataTable dtRows = dataReader.GetSchemaTable();
            foreach (DataRow item in dtRows.Rows)
            {
                dataTable.Columns.Add(item[0].ToString());
            }
            while (dataReader.Read())
            {
                DataRow item = dataTable.NewRow();
                foreach (DataColumn col in dataTable.Columns)
                {
                    if (!object.Equals(dataReader[col.ColumnName], DBNull.Value))
                    {
                        item[col.ColumnName] = dataReader[col.ColumnName];
                    }
                }
                dataTable.Rows.Add(item);
            }
            return dataTable;
        }

        /// <summary>
        /// Converts the datareader to json string
        /// </summary>
        /// <param name="dataReader">IDataReader</param>
        /// <returns>string</returns>
        public static string ToJson(this IDataReader dataReader)
        {
            try
            {
                DataTable dataTable = dataReader.ToDataTable();
                return dataTable.ToJson();
            }
            catch (Exception)
            {
            }
            return string.Empty;
        }

        /// <summary>
        /// Converts the datareader to json string
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dataReader">IDataReader</param>
        /// <param name="fromDbColumn">FromDbColumn</param>
        /// <returns>string</returns>
        public static string ToJson<T>(this IDataReader dataReader, bool fromDbColumn = true)
        {
            try
            {
                List<T> ts = dataReader.ToCollectionUsingMethod<T>(fromDbColumn: fromDbColumn);
                return ts.ToJson<T>();

            }
            catch (Exception)
            {
            }
            return string.Empty;
        }

        /// <summary>
        /// Checks if the column exists in the Datareader
        /// </summary>
        /// <param name="dataReader">IDataReader</param>
        /// <param name="columnName">ColumnName</param>
        /// <returns>bool</returns>
        public static bool HasColumn(this IDataReader dataReader, string columnName)
        {
            try
            {
                object o = dataReader[columnName];
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
