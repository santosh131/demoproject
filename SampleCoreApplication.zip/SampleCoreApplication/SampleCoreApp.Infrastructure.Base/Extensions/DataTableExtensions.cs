﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Extensions
{
    public static class DataTableExtensionHelper
    {
        /// <summary>
        /// Converts the DataTable to collection
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dataTable">DataTable</param>
        /// <param name="fromDbColumn">FromDbColumn</param>
        /// <returns>List<T></returns>
        public static List<T> ToCollection<T>(this DataTable dataTable, bool fromDbColumn = true)
        {
            if (dataTable != null)
            {
                IDataReader dataReader = dataTable.CreateDataReader();
                return dataReader.ToCollection<T>(fromDbColumn);
            }
            else
            {
                return new List<T>();
            }
        } 

        /// <summary>
        /// Converts the DataTable to Json
        /// </summary>
        /// <param name="dataTable">DataTable</param>
        /// <returns>string</returns>
        public static string ToJson(this DataTable dataTable)
        {
            try
            {
                return Newtonsoft.Json.JsonConvert.SerializeObject(dataTable);
            }
            catch (Exception)
            { 
            }
            return string.Empty;
        }
    }
}
