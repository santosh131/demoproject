﻿using Microsoft.AspNetCore.Routing;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace SampleCoreApp.Infrastructure.Base.Static
{
    public static class SecurityHelpers
    {
        public static string Encrypt(string val)
        {
            return val;
        }

        public static string Decrypt(string val)
        {
            return val;
        }

        public static string EncryptUrl(string plainText)
        {
            string key = "jdsg432387#";
            byte[] EncryptKey = { };
            byte[] IV = { 55, 34, 87, 64, 87, 195, 54, 21 };
            EncryptKey = System.Text.Encoding.UTF8.GetBytes(key.Substring(0, 8));
            DESCryptoServiceProvider des = new();
            byte[] inputByte = Encoding.UTF8.GetBytes(plainText);
            MemoryStream mStream = new ();
            CryptoStream cStream = new (mStream, des.CreateEncryptor(EncryptKey, IV), CryptoStreamMode.Write);
            cStream.Write(inputByte, 0, inputByte.Length);
            cStream.FlushFinalBlock();
            string encString = HttpUtility.UrlEncode(Convert.ToBase64String(mStream.ToArray()));
            return CleanUpEncription(encString);
        }

        public static string DecryptUrl(string encryptedText)
        {
            encryptedText = MakeItDirtyAgain(encryptedText);
            string key = "jdsg432387#";
            byte[] DecryptKey = { };
            byte[] IV = { 55, 34, 87, 64, 87, 195, 54, 21 };
            byte[] inputByte = new byte[encryptedText.Length];

            DecryptKey = System.Text.Encoding.UTF8.GetBytes(key.Substring(0, 8));
            DESCryptoServiceProvider des = new ();
            inputByte = Convert.FromBase64String(encryptedText);
            MemoryStream ms = new ();
            CryptoStream cs = new (ms, des.CreateDecryptor(DecryptKey, IV), CryptoStreamMode.Write);
            cs.Write(inputByte, 0, inputByte.Length);
            cs.FlushFinalBlock();
            System.Text.Encoding encoding = System.Text.Encoding.UTF8;
            return encoding.GetString(ms.ToArray());
        }
        public static string EncryptUrlParameters(object val)
        {
            if (val != null)
                return EncryptUrlParameters(val.ToString());
            else
                return string.Empty;
        }
        public static string EncryptUrlParameters(string plainText)
        {
            string key = "jdsg432387#";
            byte[] EncryptKey = { };
            byte[] IV = { 55, 34, 87, 64, 87, 195, 54, 21 };
            EncryptKey = System.Text.Encoding.UTF8.GetBytes(key.Substring(0, 8));
            DESCryptoServiceProvider des = new ();
            byte[] inputByte = Encoding.UTF8.GetBytes(plainText);
            MemoryStream mStream = new ();
            CryptoStream cStream = new (mStream, des.CreateEncryptor(EncryptKey, IV), CryptoStreamMode.Write);
            cStream.Write(inputByte, 0, inputByte.Length);
            cStream.FlushFinalBlock();
            string encString = HttpUtility.UrlEncode(Convert.ToBase64String(mStream.ToArray()));
            return encString;
            //return cleanUpEncription(encString);
        }

        public static string DecryptUrlParameters(string encryptedText)
        {
            //encryptedText = MakeItDirtyAgain(encryptedText);
            string key = "jdsg432387#";
            byte[] DecryptKey = { };
            byte[] IV = { 55, 34, 87, 64, 87, 195, 54, 21 };
            byte[] inputByte = new byte[encryptedText.Length];

            DecryptKey = System.Text.Encoding.UTF8.GetBytes(key.Substring(0, 8));
            DESCryptoServiceProvider des = new();
            inputByte = Convert.FromBase64String(encryptedText);
            MemoryStream ms = new ();
            CryptoStream cs = new (ms, des.CreateDecryptor(DecryptKey, IV), CryptoStreamMode.Write);
            cs.Write(inputByte, 0, inputByte.Length);
            cs.FlushFinalBlock();
            System.Text.Encoding encoding = System.Text.Encoding.UTF8;
            return encoding.GetString(ms.ToArray());
        }
        public static string RouteDataToEncrytedUrlParamters(object routeValues)
        {
            string queryString = string.Empty;
            if (routeValues != null)
            {
                RouteValueDictionary d = new (routeValues);
                for (int i = 0; i < d.Keys.Count; i++)
                {
                    if(i>0)
                    {
                        queryString += "&";
                    } 
                    queryString += d.Keys.ElementAt(i) + "=" + SecurityHelpers.EncryptUrlParameters(d.Values.ElementAt(i));
                }
                queryString = "?" + "enc=&" + queryString;
            } 
            return queryString;
        }

        public static string RouteDataToEncrytedString(object routeValues)
        {
            string queryString = string.Empty;
            if (routeValues != null)
            {
                RouteValueDictionary d = new(routeValues);
                for (int i = 0; i < d.Keys.Count; i++)
                {
                    if (i > 0)
                    {
                        queryString += "?";
                    }
                    queryString += d.Keys.ElementAt(i) + "=" + d.Values.ElementAt(i);
                }
                if (!string.IsNullOrEmpty(queryString))
                {
                    queryString = SecurityHelpers.EncryptUrl(queryString);
                }
                queryString = "?" + "q=" + queryString;
            }

            return queryString;
        }

        public static string CleanUpEncription(string encriptedstring)
        {
            string[] dirtyCharacters = { ";", "/", "?", ":", "@", "&", "=", "+", "$", "," };
            string[] cleanCharacters = { "p2n3t4G5l6m", "s1l2a3s4h", "q1e2st3i4o5n", "T22p14nt2s", "a9t", "a2n3nd", "e1q2ua88l", "p22l33u1ws", "d0l1ar5", "c0m8a1a" };

            foreach (string dirtyCharacter in dirtyCharacters)
            {
                encriptedstring = encriptedstring.Replace(dirtyCharacter, cleanCharacters[Array.IndexOf(dirtyCharacters, dirtyCharacter)]);
            }
            return encriptedstring;
        }

        public static string MakeItDirtyAgain(string encriptedString)
        {
            string[] dirtyCharacters = { ";", "/", "?", ":", "@", "&", "=", "+", "$", "," };
            string[] cleanCharacters = { "p2n3t4G5l6m", "s1l2a3s4h", "q1e2st3i4o5n", "T22p14nt2s", "a9t", "a2n3nd", "e1q2ua88l", "p22l33u1ws", "d0l1ar5", "c0m8a1a" };
            foreach (string symbol in cleanCharacters)
            {
                encriptedString = encriptedString.Replace(symbol, dirtyCharacters[Array.IndexOf(cleanCharacters, symbol)]);
            }
            return encriptedString;
        }
    }
}
