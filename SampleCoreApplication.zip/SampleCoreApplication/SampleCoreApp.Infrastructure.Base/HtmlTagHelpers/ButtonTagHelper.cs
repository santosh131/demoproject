﻿using SampleCoreApp.Infrastructure.Base.Static;
using SampleCoreApp.Infrastructure.Base.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Razor.TagHelpers;
using SampleCoreApp.Infrastructure.Base.Constants;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;

namespace SampleCoreApp.Infrastructure.Base.HtmlTagHelpers
{
    [HtmlTargetElement("button", Attributes = "field-code-models")]
    public class ButtonTagHelper : TagHelper
    { 
        public ButtonTagHelper()
        {
            
        }

        public string FieldCode { get; set; }

        public string PageCode { get; set; }

        /// <summary>
        /// Gets or Sets FieldRequired 
        /// </summary>
        /// <remarks> Leave empty or true or false</remarks>
        /// <value>String</value>
        public string FieldRequired { get; set; }

        public List<FieldCodeModel> FieldCodeModels { get; set; }

        [ViewContext]
        [HtmlAttributeNotBound]
        public ViewContext ViewContext { get; set; }

        public override async Task ProcessAsync(TagHelperContext context, TagHelperOutput output)
        {           
            string content = output.Content.IsModified ? output.Content.GetContent().Trim() :
             (await output.GetChildContentAsync()).GetContent().Trim();

            FieldRequired ??= "";
            if (FieldCodeModels != null)
            {
                FieldCodeModel fieldCodeModel = FieldCodeModels.Where(f => f.FieldCode == FieldCode && f.PageCode == PageCode).FirstOrDefault() ?? new FieldCodeModel();
                string fcDesc = fieldCodeModel?.Description;
                output.Content.AppendHtml(content + fcDesc);
            }
        }
    }
}
