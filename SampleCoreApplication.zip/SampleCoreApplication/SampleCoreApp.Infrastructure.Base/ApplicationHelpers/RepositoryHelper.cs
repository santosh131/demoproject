﻿using SampleCoreApp.Infrastructure.Base;
using SampleCoreApp.Infrastructure.Base.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.ApplicationHelpers
{
    public abstract class RepositoryHelper
    {
        public IDbHelper DbHelper;        
        public RepositoryHelper(IDbHelper dbHelper)
        {
            dbHelper.SetConnectionString(BaseApplicationAppSettings.ConnectionString);
            DbHelper = dbHelper;
        }
        
    }
}
