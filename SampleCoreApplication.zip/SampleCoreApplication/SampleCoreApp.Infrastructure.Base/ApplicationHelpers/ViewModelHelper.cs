﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.ApplicationHelpers
{
    [Serializable]
    public abstract class ViewModelHelper
    {
        /// <summary>
        /// Creates a deepy copy of the current object
        /// </summary>
        /// <returns></returns>
        public object Clone()
        {
            using MemoryStream stream = new();
            if (this.GetType().IsSerializable)
            {
                BinaryFormatter formatter = new();
                formatter.Serialize(stream, this);
                stream.Position = 0;
                return formatter.Deserialize(stream);
            }
            return null;
        }

        /// <summary>
        /// Converts the current object to Json
        /// </summary>        
        /// <returns>string</returns>
        public string ToJson()
        {
            try
            {
                return Newtonsoft.Json.JsonConvert.SerializeObject(this);
            }
            catch (Exception)
            {
            }
            return string.Empty;
        }
    }
}
