﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using SampleCoreApp.Infrastructure.Base.Extensions;

namespace SampleCoreApp.Infrastructure.Base.ApplicationHelpers
{
    [Serializable]
    public abstract class ModelHelper
    {
        public virtual object Fill(IDataReader dr, bool fromDbColumn)
        {
            if (dr != null)
            {
                PropertyInfo[] pInfo = this.GetType().GetProperties();
                string colName;
                for (int i = 0; i < pInfo.Length; i++)
                {
                    colName = pInfo[i].Name;
                    if (fromDbColumn)
                    {
                        colName = AttributesHelper.GetDbColumnAttributeVal(pInfo[i]);
                    }
                    if (!string.IsNullOrEmpty(colName))
                    {
                        if (dr.HasColumn(colName))
                        {
                            if (dr[colName] != null && dr[colName] != DBNull.Value)
                            {
                                if (pInfo[i].PropertyType == typeof(string))
                                    pInfo[i].SetValue(this, dr[colName].ToString());
                                else if (pInfo[i].PropertyType == typeof(int) ||
                                        pInfo[i].PropertyType == typeof(Nullable<int>))
                                {
                                    if (dr[colName].ToString().IsInteger())
                                        pInfo[i].SetValue(this, dr[colName].ToString().ToNullableInteger());
                                }
                                else if (pInfo[i].PropertyType == typeof(Int64) ||
                                        pInfo[i].PropertyType == typeof(Nullable<Int64>))
                                {
                                    if (dr[colName].ToString().IsInteger64())
                                        pInfo[i].SetValue(this, dr[colName].ToString().ToNullableInteger64());
                                }
                                else if (pInfo[i].PropertyType == typeof(decimal) ||
                                        pInfo[i].PropertyType == typeof(Nullable<decimal>))
                                {
                                    pInfo[i].SetValue(this, dr[colName].ToString().ToNullableDecimal());
                                }
                                else if (pInfo[i].PropertyType == typeof(double) ||
                                        pInfo[i].PropertyType == typeof(Nullable<double>))
                                {
                                    pInfo[i].SetValue(this, dr[colName].ToString().ToNullableDouble());
                                }
                                else if (pInfo[i].PropertyType == typeof(float) ||
                                        pInfo[i].PropertyType == typeof(Nullable<float>))
                                {
                                    pInfo[i].SetValue(this, dr[colName].ToString().ToNullableFloat());
                                }
                                else if (pInfo[i].PropertyType == typeof(bool) ||
                                        pInfo[i].PropertyType == typeof(Nullable<bool>))
                                {
                                    pInfo[i].SetValue(this, dr[colName].ToString().ToNullableBool());
                                }
                                else if (pInfo[i].PropertyType == typeof(DateTime) ||
                                        pInfo[i].PropertyType == typeof(Nullable<DateTime>))
                                {
                                    pInfo[i].SetValue(this, dr[colName].ToString().ToNullableDateTime());
                                }
                            }
                        }
                    }

                }
            }

            return this;
        }

        public virtual object FillUsingPropInfo(IDataReader dr, PropertyInfo[] pInfo, Dictionary<string, string> dicKeyValues, bool fromDbColumn)
        {
            if (dr != null && pInfo != null)
            {
                string colName;
                for (int i = 0; i < pInfo.Length; i++)
                {
                    colName = pInfo[i].Name;
                    if (fromDbColumn)
                    {
                        dicKeyValues.TryGetValue(pInfo[i].Name, out colName);
                    }
                    if (!string.IsNullOrEmpty(colName))
                    {
                        if (dr.HasColumn(colName))
                        {
                            if (dr[colName] != null && dr[colName] != DBNull.Value)
                            {
                                if (pInfo[i].PropertyType == typeof(string))
                                    pInfo[i].SetValue(this, dr[colName].ToString());
                                else if (pInfo[i].PropertyType == typeof(int) ||
                                        pInfo[i].PropertyType == typeof(Nullable<int>))
                                {
                                    if (dr[colName].ToString().IsInteger())
                                        pInfo[i].SetValue(this, dr[colName].ToString().ToNullableInteger());
                                }
                                else if (pInfo[i].PropertyType == typeof(Int64) ||
                                        pInfo[i].PropertyType == typeof(Nullable<Int64>))
                                {
                                    if (dr[colName].ToString().IsInteger64())
                                        pInfo[i].SetValue(this, dr[colName].ToString().ToNullableInteger64());
                                }
                                else if (pInfo[i].PropertyType == typeof(decimal) ||
                                        pInfo[i].PropertyType == typeof(Nullable<decimal>))
                                {
                                    pInfo[i].SetValue(this, dr[colName].ToString().ToNullableDecimal());
                                }
                                else if (pInfo[i].PropertyType == typeof(double) ||
                                        pInfo[i].PropertyType == typeof(Nullable<double>))
                                {
                                    pInfo[i].SetValue(this, dr[colName].ToString().ToNullableDouble());
                                }
                                else if (pInfo[i].PropertyType == typeof(float) ||
                                        pInfo[i].PropertyType == typeof(Nullable<float>))
                                {
                                    pInfo[i].SetValue(this, dr[colName].ToString().ToNullableFloat());
                                }
                                else if (pInfo[i].PropertyType == typeof(bool) ||
                                        pInfo[i].PropertyType == typeof(Nullable<bool>))
                                {
                                    pInfo[i].SetValue(this, dr[colName].ToString().ToNullableBool());
                                }
                                else if (pInfo[i].PropertyType == typeof(DateTime) ||
                                        pInfo[i].PropertyType == typeof(Nullable<DateTime>))
                                {
                                    pInfo[i].SetValue(this, dr[colName].ToString().ToNullableDateTime());
                                }
                            }
                        }
                    }

                }
            }

            return this;
        }

        /// <summary>
        /// Gets the DbColumnNameAttribute value
        /// </summary>
        /// <param name="propertyName"></param>
        /// <returns>string</returns>
        /// <remarks> get the value if DbColumnNameAttribute exists  otherwise returns string.empty</remarks>
        public string GetDBColumnName(string propertyName)
        {
            string colName = string.Empty;
            try
            {
                if (!string.IsNullOrEmpty(propertyName))
                {
                    PropertyInfo pInfo = this.GetType().GetProperty(propertyName);
                    if (pInfo != null)
                    {
                        object[] attrs = pInfo.GetCustomAttributes(typeof(DbColumnNameAttribute), false);
                        if (attrs != null && attrs.Length > 0)
                        {
                            colName = ((DbColumnNameAttribute)attrs[0]).Name;
                        }
                    }
                }
            }
            catch (Exception)
            {
            }
            return colName;
        }

        /// <summary>
        /// Creates a deepy copy of the current object
        /// </summary>
        /// <returns></returns>
        public object Clone()
        {
            using MemoryStream stream = new();
            if (this.GetType().IsSerializable)
            {
                BinaryFormatter formatter = new();
                formatter.Serialize(stream, this);
                stream.Position = 0;
                return formatter.Deserialize(stream);
            }
            return null;
        }

        /// <summary>
        /// Converts the current object to Json
        /// </summary>        
        /// <returns>string</returns>
        public string ToJson()
        {
            try
            {
                return Newtonsoft.Json.JsonConvert.SerializeObject(this);
            }
            catch (Exception)
            {
            }
            return string.Empty;
        }
    }
}
