﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.ApplicationHelpers
{
    public static class ObjectHelper
    {
        /// <summary>
        /// Converts the object to Json
        /// </summary>
        /// <param name="T">T</param>
        /// <returns>string</returns>
        public static string ToJsonString<T>(T o)
        {
            try
            {
                return Newtonsoft.Json.JsonConvert.SerializeObject(o);
            }
            catch (Exception)
            {
            }
            return string.Empty;
        } 
    }
}
