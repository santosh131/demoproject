﻿using SampleCoreApp.Infrastructure.Base.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Interfaces
{
    public interface IGenericReadAllRepository<T, TCommon, TMessage, TSortingPaging>
    {
        List<T> GetAll(T t, TCommon tcommon, ref TMessage tmessage, ref TSortingPaging tSortingPaging);
    }

    public interface IGenericReadAllRepository<T1, T2, TCommon, TMessage, TSortingPaging>
    {
        List<T1> GetAll(T1 t1, T2 t2, TCommon tcommon, ref TMessage tmessage, ref TSortingPaging tSortingPaging);
    }

    public interface IGenericReadAllRepository<T1, T2, T3, TCommon, TMessage, TSortingPaging>
    {
        List<T1> GetAll(T1 t1, T2 t2, T3 t3, TCommon tcommon, ref TMessage tmessage, ref TSortingPaging tSortingPaging);
    }
}
