﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Interfaces
{
    public interface IGenericSaveRepository<T, TCommon, TMessage, TSortingPaging>
    {
        void Save(T t, TCommon tcommon, ref TMessage tmessage);
        void Validate(T t, TCommon tcommon, ref TMessage tmessage);
    }

    public interface IGenericSaveRepository<T1,T2, TCommon, TMessage, TSortingPaging>
    {
        void Save(T1 t1,T2 t2, TCommon tcommon, ref TMessage tmessage);
        void Validate(T1 t1, T2 t2, TCommon tcommon, ref TMessage tmessage);
    }

    public interface IGenericSaveRepository<T1, T2,T3, TCommon, TMessage, TSortingPaging>
    {
        void Save(T1 t1, T2 t2,T3 t3, TCommon tcommon, ref TMessage tmessage);
        void Validate(T1 t1, T2 t2,T3 t3, TCommon tcommon, ref TMessage tmessage);
    }
}
