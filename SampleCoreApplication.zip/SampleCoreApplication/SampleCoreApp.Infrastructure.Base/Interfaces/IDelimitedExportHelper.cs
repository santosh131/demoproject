﻿using SampleCoreApp.Infrastructure.Base.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Interfaces
{
    public interface IDelimitedExportHelper
    {
        /// <summary>
        /// Exports the Data
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dataSource">DataSource</param> 
        /// <param name="exportFileName">ExportFileName</param>
        /// <param name="configDataSource">Configuration DataSource</param>
        /// <param name="delimitedText">DelimitedText</param>
        /// <param name="hasfileNameDateTime">HasfileNameDateTime</param> 
        void Export<T>(T dataSource, string exportFileName, T configDataSource,string delimitedText=",", bool hasfileNameDateTime = false);
    }
}
