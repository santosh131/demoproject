﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Interfaces
{
    public interface ICacheHelper
    {
        /// <summary>
        /// Clears the entire cache
        /// </summary>
        /// <returns>bool</returns>
        bool ClearAllCache();

        /// <summary>
        /// Clears specific cache using the key
        /// </summary>
        /// <param name="key"></param>
        /// <returns>bool</returns>
        bool ClearCache(string key);

        /// <summary>
        /// Gets the object from cache
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <returns>T</returns>
        T GetFromCache<T>(string key);

        /// <summary>
        /// Sets the object to cache
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <param name="dataSource"></param>
        void SetToCache<T>(string key, T dataSource);        
    }
}
