﻿using SampleCoreApp.Infrastructure.Base.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Interfaces
{
    public interface IGenericReadWriteRepository<T, TCommon, TMessage, TSortingPaging> :
        IGenericReadRepository<T, TCommon, TMessage, TSortingPaging>,
        IGenericWriteRepository<T, TCommon, TMessage, TSortingPaging>
    {

    }

    public interface IGenericReadWriteRepository<T1, T2, TCommon, TMessage, TSortingPaging> :
      IGenericReadRepository<T1, T2, TCommon, TMessage, TSortingPaging>,
      IGenericWriteRepository<T1, T2, TCommon, TMessage, TSortingPaging>
    {

    }

    public interface IGenericReadWriteRepository<T1, T2, T3, TCommon, TMessage, TSortingPaging> :
      IGenericReadRepository<T1, T2, T3, TCommon, TMessage, TSortingPaging>,
      IGenericWriteRepository<T1, T2, T3, TCommon, TMessage, TSortingPaging>
    {

    }
}
