﻿using SampleCoreApp.Infrastructure.Base.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Interfaces
{
    public interface IGenericReadRepository<T, TCommon, TMessage, TSortingPaging> :
        IGenericReadAllRepository<T, TCommon, TMessage, TSortingPaging>,
        IGenericReadSingleRepository<T, TCommon, TMessage, TSortingPaging>
    {
    }

    public interface IGenericReadRepository<T1, T2, TCommon, TMessage, TSortingPaging> :
        IGenericReadAllRepository<T1, T2, TCommon, TMessage, TSortingPaging>,
        IGenericReadSingleRepository<T1, T2, TCommon, TMessage, TSortingPaging>
    {
    }

    public interface IGenericReadRepository<T1, T2, T3, TCommon, TMessage, TSortingPaging> :
        IGenericReadAllRepository<T1, T2, T3, TCommon, TMessage, TSortingPaging>,
        IGenericReadSingleRepository<T1, T2, T3, TCommon, TMessage, TSortingPaging>
    {
    }
}
