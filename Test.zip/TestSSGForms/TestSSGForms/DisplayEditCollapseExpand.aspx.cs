﻿///===============================================================================================
///Object Name          : DisplayEditCollapseExpand
///Object Type		    : Class
///Purpose			    : 

///Change History
///------------------------------------------------------------------------------------------------
///    Date         	Modified by	    Remarks  
///------------------------------------------------------------------------------------------------
///    09/26/2016	    Santosh	 	    Initial Version
///=============================================================================================== 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace TestSSGForms
{
    public partial class DisplayEditCollapseExpand : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnGetData_Click(object sender, EventArgs e)
        {
            DataTable dtConfig = new HelperMethods().GetPageConfigField("PD001", "SD0002").Tables[0];
            DataTable dtObsData = new HelperMethods().GetObservationData().Tables[0];

            fvObsCollExp.AllowEdit = true;
            fvObsCollExp.LayoutDataSource = dtConfig;
            fvObsCollExp.DataSource = dtObsData;
            fvObsCollExp.DataBind();
        }


        protected void btnCollExp_Click(object sender, EventArgs e)
        {

        }

    }
}