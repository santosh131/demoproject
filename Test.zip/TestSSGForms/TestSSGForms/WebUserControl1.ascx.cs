﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace TestSSGForms
{
    public partial class WebUserControl1 : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void btnGetData_Click(object sender, EventArgs e)
        {
            DataTable dtConfig = new HelperMethods().GetPageConfigField("PD001", "SD0001").Tables[0];
            DataTable dtObsData = new HelperMethods().GetObservationData().Tables[0];
            fvObs.LayoutDataSource = dtConfig;
            fvObs.DataSource = dtObsData;
            fvObs.DataBind();


            dtConfig = new HelperMethods().GetPageConfigField("PD001", "SD0002").Tables[0];
            fvObsEdit.AllowEdit = true;
            fvObsEdit.LayoutDataSource = dtConfig;                
            fvObsEdit.DataSource = dtObsData;
            fvObsEdit.DataBind();

            
            fvObsCollExp.AllowEdit = true;
            fvObsCollExp.LayoutDataSource = dtConfig;
            fvObsCollExp.DataSource = dtObsData;
            fvObsCollExp.DataBind();
        }

        protected void btnCloseModal_Click(object sender, EventArgs e)
        {

        }

        protected void btnCollExp_Click(object sender, EventArgs e)
        {

        }
    }
}