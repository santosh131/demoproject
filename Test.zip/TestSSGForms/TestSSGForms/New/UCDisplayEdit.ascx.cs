﻿///===============================================================================================
///Object Name          : UCDisplayEdit
///Object Type		    : Class
///Purpose			    : 

///Change History
///------------------------------------------------------------------------------------------------
///    Date         	Modified by	    Remarks  
///------------------------------------------------------------------------------------------------
///    09/26/2016	    Santosh	 	    Initial Version
///=============================================================================================== 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using SSG.CustomControls;

namespace TestSSGForms.New
{
    public partial class UCDisplayEdit : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void btnGetData_Click(object sender, EventArgs e)
        {
            DataTable dtConfig = new HelperMethods().GetPageConfigField("PD001", "SD0002").Tables[0];
            DataTable dtObsData = new HelperMethods().GetObservationData().Tables[0];

           
            fvObsEdit.LayoutDataSource = dtConfig;
            fvObsEdit.EnableFields= true;
            fvObsEdit.DataSource = dtObsData;
            fvObsEdit.DataBind();

            fvObsEdit.EnableDisableField("M0015", false);

            fvObsEdit.SetTableCellValueCss("M0015","testClass");
            fvObsEdit.SetTableCellCss("OBXXX", "infoClass");

            dtConfig = new HelperMethods().GetPageConfigField("PD001", "SD0002").Tables[0];
            FormView1.LayoutDataSource = dtConfig;
            FormView1.EnableFields = true;
            FormView1.DataSource = dtObsData;
            FormView1.DataBind();
            FormView1.EnableDisableField("OB1065", false);
            FormView1.SetTableCellCss("OBXXX", "infoClass");
            
            
        }

        protected void fvObsEdit_CreateField(object sender, SSG.CustomControls.CreateFieldEventArgs e)
        {
            if (e.FieldItem.FieldCode == "M0015")
            {
                DropDownList ddlSchool = e.Control as DropDownList;
                if (ddlSchool != null)
                {
                    ListItem item = new ListItem();
                    item.Value = e.FieldItem.DataValue;
                    item.Text = "Sample school 1";
                    ddlSchool.Items.Add(item);
                    item = new ListItem();
                    item.Value = "abc";
                    item.Text = "Sample school 2";
                    ddlSchool.Items.Add(item);
                    ddlSchool.DataBind();
                }
            }
        }

        protected void fvObsEdit_Cascade(object sender, SSG.CustomControls.CascadeEventArgs e)
        {
            
        }

        protected void btnGetData2_Click(object sender, EventArgs e)
        {
            FormViewItems fvItems = fvObsEdit.RetriveData();
            FormViewItem fv=    fvItems.GetItem("M0015");
            FormViewItem fv2 = FormView1.RetriveData().GetItem("M0015");
        }
         
    }
}