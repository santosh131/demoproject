﻿///===============================================================================================
///Object Name          : UCDisplay
///Object Type		    : Class
///Purpose			    : 

///Change History
///------------------------------------------------------------------------------------------------
///    Date         	Modified by	    Remarks  
///------------------------------------------------------------------------------------------------
///    09/26/2016	    Santosh	 	    Initial Version
///=============================================================================================== 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace TestSSGForms.New
{
    public partial class UCDisplay : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void btnGetData_Click(object sender, EventArgs e)
        {
            DataTable dtConfig = new HelperMethods().GetPageConfigField("PD001", "SD0001").Tables[0];
            DataTable dtObsData = new HelperMethods().GetObservationData().Tables[0];
            fvObs.LayoutDataSource = dtConfig;
            fvObs.DataSource = dtObsData;
            fvObs.DataBind();


            fvObsHorizontal.LayoutDataSource = dtConfig;
            fvObsHorizontal.DataSource = dtObsData;
            fvObsHorizontal.DataBind();
        }
    }
}