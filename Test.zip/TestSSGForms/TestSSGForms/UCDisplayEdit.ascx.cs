﻿///===============================================================================================
///Object Name          : UCDisplayEdit
///Object Type		    : Class
///Purpose			    : 

///Change History
///------------------------------------------------------------------------------------------------
///    Date         	Modified by	    Remarks  
///------------------------------------------------------------------------------------------------
///    09/26/2016	    Santosh	 	    Initial Version
///=============================================================================================== 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace TestSSGForms
{
    public partial class UCDisplayEdit : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void btnGetData_Click(object sender, EventArgs e)
        {
            DataTable dtConfig = new HelperMethods().GetPageConfigField("PD001", "SD0001").Tables[0];
            DataTable dtObsData = new HelperMethods().GetObservationData().Tables[0];

            dtConfig = new HelperMethods().GetPageConfigField("PD001", "SD0002").Tables[0];
            fvObsEdit.AllowEdit = false;
            fvObsEdit.LayoutDataSource = dtConfig;
            fvObsEdit.DataSource = dtObsData;
            fvObsEdit.DataBind();

        }
         

        protected void fvObsEdit_CreateField(object sender, MaxWebUI.FormView.CreateFieldEventArgs e)
        {
            if (e.FieldItem.FieldKey== "M0015")
            {
                DropDownList ddlSchool = e.Control as DropDownList;
                if (ddlSchool != null)
                {
                    ListItem item = new ListItem();
                    item.Value = e.FieldItem.DataValue;
                    item.Text = "Sample school 1";
                    ddlSchool.Items.Add(item);
                    ddlSchool.DataBind();
                }
            }
        }
         

        protected void fvObsEdit_DDLCascade(object sender, MaxWebUI.FormView.DDLCascadeEventArgs e)
        {

        }
    }
}