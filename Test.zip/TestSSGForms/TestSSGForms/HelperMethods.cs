﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.ComponentModel;
using System.Data;
using System.Drawing;

using System.Text;
using System.IO;

using System.Data.SqlClient;
using System.Configuration;

namespace TestSSGForms
{
    public class HelperMethods
    {
        SqlConnection conn = new SqlConnection("Data Source=SSGDB1;Initial Catalog=QA_MAC3;Integrated Security=SSPI;uid=santosh;pwd=santosh5");

        private int paramCount = 0;
        private void SetParameter(SqlCommand cmd, string paramName, SqlDbType type, int size, ParameterDirection direction, object value)
        {
            if (type != SqlDbType.Int)
            {
                cmd.Parameters.Add(paramName, type, size);
            }
            else
            {
                cmd.Parameters.Add(paramName, type);
            }
            cmd.Parameters[paramCount].Direction = direction;
            cmd.Parameters[paramCount].Value = value;
            paramCount++;
        }

     
        public DataSet GetPageConfigField(string pageCode, string sectionCode)
        {
            DataSet ds = new DataSet();
            string strSql = "PCMN_PAGE_CONFIG_FIELD_LIST";

            SqlCommand cmd = new SqlCommand(strSql, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            paramCount = 0;
            //Adding Parameters 
            SetParameter(cmd, "@pin_page_cd", SqlDbType.NVarChar, 10, ParameterDirection.Input,pageCode);
            SetParameter(cmd, "@pin_section_cd", SqlDbType.NVarChar, 10, ParameterDirection.Input, sectionCode);
            
            conn.Open();

            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = cmd;
            adapter.Fill(ds, "Table");
          
            return ds;
        }

        public DataSet GetObservationData()
        {
            DataSet ds = new DataSet();
            string strSql = "PRMS_OBSERVATION_GET";

            SqlCommand cmd = new SqlCommand(strSql, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            paramCount = 0;
            //Adding Parameters 
            SetParameter(cmd, "@pin_observation_said", SqlDbType.Int, 10, ParameterDirection.Input, 155755);

            conn.Open();

            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = cmd;
            adapter.Fill(ds, "Table");

            return ds;
        }
    }
}