﻿///===============================================================================================
///Object Name          : CreateFieldEventArgs
///Object Type		    : Class
///Purpose			    : To be used as EventArgs for CreateField

///Change History
///------------------------------------------------------------------------------------------------
///    Date         	Modified by	    Remarks  
///------------------------------------------------------------------------------------------------
///    09/26/2016	    Santosh	 	    Initial Version
///=============================================================================================== 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;

namespace SSG.CustomControls
{
    public class CascadeEventArgs : EventArgs
    {
        public FormViewItem FieldItem;
        public WebControl Control;
    }
}
