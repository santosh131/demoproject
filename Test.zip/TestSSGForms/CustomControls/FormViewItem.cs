﻿///===============================================================================================
///Object Name          : FormViewItem
///Object Type		    : Class
///Purpose			    : Each Item for Form

///Change History
///------------------------------------------------------------------------------------------------
///    Date         	Modified by	    Remarks  
///------------------------------------------------------------------------------------------------
///    09/26/2016	    Santosh	 	    Initial Version
///=============================================================================================== 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using SSG.CommonBusinessEntity;
using SSG.CommonBusinessEntity.Base;
using System.Web.UI.WebControls;

namespace SSG.CustomControls
{
    [Serializable]
    public class FormViewItem
    {
        #region Private Variables

        private string _field_name_txt;
        private string _field_cd;
        private string _caption_txt;
        private string _data_value_txt;
        private string _data_desc_txt;
        private string _field_type_cd;
        private string _sub_field_type_cd; 
        private string _parent_field_cd;
        private bool _cascade_ind;
        private bool _mandatory_ind;
        private bool _allowView_ind;
        private bool _allowEdit_ind;
        private int _max_length_nbr;
        private int _display_width_nbr;
        private DataTable _data_value_tb;
        #endregion

        #region Constructors

        public FormViewItem()
        {
            _field_name_txt = string.Empty;
            _field_cd = string.Empty;
            _caption_txt = string.Empty;
            _data_value_txt = string.Empty;
            _data_desc_txt = string.Empty;
            _field_type_cd = string.Empty;
            _sub_field_type_cd = string.Empty; 
            _parent_field_cd = string.Empty;
            _cascade_ind = false;
            _mandatory_ind = false;
            _allowView_ind = false;
            _allowEdit_ind = false;
            _max_length_nbr = 0;
            _display_width_nbr = 0;
        }

        public FormViewItem(string fieldName, string fieldCd,string subfieldtypecd, string caption, string dataValue, string dataText, string fieldTypeCode, string parentFieldCd, bool cascadeInd, bool mandatoryInd,
        bool allowViewInd, bool allowEditInd, int maxLengthNbr,int display_width_nbr)
        {
            _field_name_txt = fieldName;
            _field_cd = fieldCd;
            _sub_field_type_cd = subfieldtypecd;
            _caption_txt = caption;
            _data_value_txt = dataValue;
            _data_desc_txt = dataText;
            _field_type_cd = fieldTypeCode; 
            _parent_field_cd = parentFieldCd;
            _cascade_ind = cascadeInd;
            _mandatory_ind = mandatoryInd;
            _allowView_ind = allowViewInd;
            _allowEdit_ind = allowEditInd;
            _max_length_nbr = maxLengthNbr;
            _display_width_nbr = display_width_nbr;
        }
         
        #endregion

        #region Public Properties

        /// <summary>
        /// Gets the FieldName
        /// </summary>
        public string FieldName
        {
            get { return _field_name_txt; }
        }

        /// <summary>
        /// Gets the FieldCode
        /// </summary>
        public string FieldCode
        {
            get { return _field_cd; }
        }

        /// <summary>
        /// Gets the Caption
        /// </summary>
        public string Caption
        {
            get { return _caption_txt; }
        }

        /// <summary>
        /// Gets or Sets the DataValue
        /// </summary>
        public string DataValue
        {
            get { return _data_value_txt; }
            set { _data_value_txt = value; }
        }

        /// <summary>
        /// Gets or Sets the DataValueTable
        /// </summary>
        public DataTable DataValueTable
        {
            get { return _data_value_tb; }
            set { _data_value_tb = value; }
        }

        /// <summary>
        /// Gets or Sets  the DataText
        /// </summary>
        public string DataText
        {
            get { return _data_desc_txt; }
            set { _data_desc_txt = value; }
        }

        /// <summary>
        /// Gets the FieldTypeCode
        /// </summary>
        public string FieldTypeCode
        {
            get { return _field_type_cd; }
        } 

        /// <summary>
        /// Gets the ParentFieldCode
        /// </summary>
        public string ParentFieldCode
        {
            get { return _parent_field_cd; }
        }

        /// <summary>
        /// Gets the Cascade
        /// </summary>
        public bool Cascade
        {
            get { return _cascade_ind; }
        }

        /// <summary>
        /// Gets the Mandatory
        /// </summary>
        public bool Mandatory
        {
            get { return _mandatory_ind; }
        }

        /// <summary>
        /// Gets the AllowView
        /// </summary>
        public bool AllowView
        {
            get { return _allowView_ind; }
        }

        /// <summary>
        /// Gets the AllowEdit
        /// </summary>
        public bool AllowEdit
        {
            get { return _allowEdit_ind; }
        }

        /// <summary>
        /// Gets the Size
        /// </summary>
        public int MaxLength
        {
            get { return _max_length_nbr; }
        }


        /// <summary>
        /// Gets the DiplayWidthNbr
        /// </summary>
        public int DiplayWidthNbr
        {
            get { return _display_width_nbr; }
        }
         
        #endregion
    }
}
