Imports System.Web.UI
Imports System.Web.UI.WebControls

Namespace MaxWebUI.FormView

    Public Class CreateFieldEventArgs : Inherits EventArgs
        Public FieldItem As FormViewItem
        Public Control As WebControl
    End Class

    Public Class DDLCascadeEventArgs : Inherits EventArgs
        Public FieldItem As FormViewItem
    End Class

End Namespace