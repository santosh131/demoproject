Imports System.ComponentModel
Imports System.Web.UI
Imports System.Web.UI.WebControls

Namespace MaxWebUI.FormView

    <Serializable()> _
    Public Class FormViewItem
        Private m_sFieldName As String
        Private m_sFieldKey As String
        Private m_sCaption As String
        Private m_sDataValue As String
        Private m_sDataText As String
        Private m_sDataType As String
        Private m_sChildFieldKey As String
        Private m_sParentFieldKey As String
        Private m_bCascade As Boolean
        Private m_bMandatory As Boolean
        Private m_bAllowView As Boolean
        Private m_bAllowEdit As Boolean
        Private m_iSize As Integer

        Public Sub New()
            m_sFieldName = String.Empty
            m_sFieldKey = String.Empty
            m_sCaption = String.Empty
            m_sDataValue = String.Empty
            m_sDataText = String.Empty
            m_sDataType = String.Empty
            m_sChildFieldKey = String.Empty
            m_sParentFieldKey = String.Empty
            m_bCascade = False
            m_bMandatory = False
            m_bAllowView = False
            m_bAllowEdit = False
            m_iSize = 0
        End Sub

        Public Sub New(ByVal sFieldName As String, ByVal sFieldKey As String, ByVal sCaption As String, ByVal sDataValue As String, ByVal sDataText As String, _
                    ByVal sDataType As String, ByVal sChildFieldKey As String, ByVal sParentFieldKey As String, ByVal bCascade As Boolean, ByVal bMandatory As Boolean, ByVal bAllowView As Boolean, ByVal bAllowEdit As Boolean, ByVal iSize As Integer)
            m_sFieldName = sFieldName
            m_sFieldKey = sFieldKey
            m_sCaption = sCaption
            m_sDataValue = sDataValue
            m_sDataText = sDataText
            m_sDataType = sDataType
            m_sChildFieldKey = sChildFieldKey
            m_sParentFieldKey = sParentFieldKey
            m_bCascade = bCascade
            m_bMandatory = bMandatory
            m_bAllowView = bAllowView
            m_bAllowEdit = bAllowEdit
            m_iSize = iSize
        End Sub

        Public ReadOnly Property FieldName() As String
            Get
                Return m_sFieldName
            End Get
        End Property

        Public ReadOnly Property FieldKey() As String
            Get
                Return m_sFieldKey
            End Get
        End Property

        Public ReadOnly Property Caption() As String
            Get
                Return m_sCaption
            End Get
        End Property

        Public Property DataValue() As String
            Get
                Return m_sDataValue
            End Get
            Set(ByVal Value As String)
                m_sDataValue = Value
            End Set
        End Property

        Public Property DataText() As String
            Get
                Return m_sDataText
            End Get
            Set(ByVal Value As String)
                m_sDataText = Value
            End Set
        End Property

        Public ReadOnly Property DataType() As String
            Get
                Return m_sDataType
            End Get
        End Property

        Public ReadOnly Property ChildFieldKey() As String
            Get
                Return m_sChildFieldKey
            End Get
        End Property

        Public ReadOnly Property ParentFieldKey() As String
            Get
                Return m_sParentFieldKey
            End Get
        End Property

        Public ReadOnly Property Cascade() As Boolean
            Get
                Return m_bCascade
            End Get
        End Property

        Public ReadOnly Property Mandatory() As Boolean
            Get
                Return m_bMandatory
            End Get
        End Property

        Public ReadOnly Property AllowView() As Boolean
            Get
                Return m_bAllowView
            End Get
        End Property

        Public ReadOnly Property AllowEdit() As Boolean
            Get
                Return m_bAllowEdit
            End Get
        End Property

        Public ReadOnly Property Size() As Integer
            Get
                Return m_iSize
            End Get
        End Property

    End Class

End Namespace