Imports System.ComponentModel
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Collections



Namespace MaxWebUI.FormView

    Public Enum FormViewMode As Integer
        ViewOnly = 0
        Edit = 1
        Insert = 2
        'Delete = 3  'For Future use
    End Enum

End Namespace