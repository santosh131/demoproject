'============================================================================
'	Object Name          		: FormView
'	Object Type		    		: Class
'    Change History
'    --------------
'    Modified Date		Modified by		Remarks  
'    ------------------------------------------------------------------------
'    -                  -               -
'    -                  -               New Class
'    02/10/2014          Santosh        Added functionality to merge the two columns 
'                                       for the DataType- Filler 
'============================================================================ 
Imports System.ComponentModel
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.IO
Imports System.Collections.Specialized

Namespace MaxWebUI.FormView

    <ToolboxData("<{0}:FormView runat=server></{0}:FormView>")> _
    Public Class FormView : Inherits WebControl : Implements INamingContainer

#Region "Events"

        Public Delegate Sub CreateFieldEventHandler(ByVal sender As Object, ByVal e As CreateFieldEventArgs)
        Public Event CreateField As CreateFieldEventHandler

        Public Delegate Sub DDLCascadeEventHandler(ByVal sender As Object, ByVal e As DDLCascadeEventArgs)
        Public Event DDLCascade As DDLCascadeEventHandler

#End Region

#Region "Private members"

        Private m_oDataSource As Object
        Private m_oLayoutDataSource As Object
        Private m_oItemStyle As TableItemStyle
        Private m_oAltItemStyle As TableItemStyle
        Private m_oHeaderStyle As TableItemStyle
        Private m_oFooterStyle As TableItemStyle
        Private m_bUseDataSource As Boolean = False

        Private m_blIsColAdded As Boolean = False ' Temp fix for two column display

#End Region

#Region "Properties"

        ' Text to show in the header row
        Public Property HeaderText() As String
            Get
                Return Convert.ToString(ViewState("HeaderText"))
            End Get
            Set(ByVal Value As String)
                ViewState("HeaderText") = Value
            End Set
        End Property

        ' Text to show in the footer row
        Public Property FooterText() As String
            Get
                Return Convert.ToString(ViewState("FooterText"))
            End Get
            Set(ByVal Value As String)
                ViewState("FooterText") = Value
            End Set
        End Property

        ' Enable the cotrols for editing
        Public Property AllowEdit() As Boolean
            Get
                Return Convert.ToBoolean(ViewState("AllowEdit"))
            End Get
            Set(ByVal Value As Boolean)
                ViewState("AllowEdit") = Value
                CurrentMode = FormViewMode.Edit
            End Set
        End Property

        'Css for Header
        Public Property CssHeader() As String
            Get
                Return Convert.ToString(ViewState("CssHeader"))
            End Get
            Set(ByVal Value As String)
                ViewState("CssHeader") = Value
            End Set
        End Property

        'Css for Error
        Public Property CssError() As String
            Get
                Return Convert.ToString(ViewState("CssError"))
            End Get
            Set(ByVal Value As String)
                ViewState("CssError") = Value
            End Set
        End Property

        'Css for Footer
        Public Property CssFooter() As String
            Get
                Return Convert.ToString(ViewState("CssError"))
            End Get
            Set(ByVal Value As String)
                ViewState("CssError") = Value
            End Set
        End Property

        'Css for Captions
        Public Property CssCaption() As String
            Get
                Return Convert.ToString(ViewState("CssCaption"))
            End Get
            Set(ByVal Value As String)
                ViewState("CssCaption") = Value
            End Set
        End Property

        'Added by Santosh 02/10/2014
        'Begin
        'Css for Filler Caption
        Public Property CssFillerCaption() As String
            Get
                If Not IsNothing(ViewState("CssFillerCaption")) Then
                    Return Convert.ToString(ViewState("CssFillerCaption"))
                Else
                    Return String.Empty
                End If
            End Get
            Set(ByVal Value As String)
                ViewState("CssFillerCaption") = Value
            End Set
        End Property
        'End

        'Css for Values
        Public Property CssValue() As String
            Get
                Return Convert.ToString(ViewState("CssValue"))
            End Get
            Set(ByVal Value As String)
                ViewState("CssValue") = Value
            End Set
        End Property

        'Css for Labels
        Public Property CssLabel() As String
            Get
                Return Convert.ToString(ViewState("CssLabel"))
            End Get
            Set(ByVal Value As String)
                ViewState("CssLabel") = Value
            End Set
        End Property

        'Css for Textbox
        Public Property CssTextBox() As String
            Get
                Return Convert.ToString(ViewState("CssTextBox"))
            End Get
            Set(ByVal Value As String)
                ViewState("CssTextBox") = Value
            End Set
        End Property

        'Css for DropDown
        Public Property CssDropDown() As String
            Get
                Return Convert.ToString(ViewState("CssDropDown"))
            End Get
            Set(ByVal Value As String)
                ViewState("CssDropDown") = Value
            End Set
        End Property

        'Css for CheckBox
        Public Property CssCheckBox() As String
            Get
                Return Convert.ToString(ViewState("CssCheckBox"))
            End Get
            Set(ByVal Value As String)
                ViewState("CssCheckBox") = Value
            End Set
        End Property


        'In how many Columns the data need to be displayed.
        Public Property ColumnCount() As Integer
            Get
                Return Convert.ToInt32(ViewState("ColumnCount"))
            End Get
            Set(ByVal Value As Integer)
                ViewState("ColumnCount") = Value
            End Set
        End Property

        'In how many Columns the data need to be displayed.
        Public Property TotalVisibleRows() As Integer
            Get
                Return Convert.ToInt32(ViewState("TotalVisibleRows"))
            End Get
            Set(ByVal Value As Integer)
                ViewState("TotalVisibleRows") = Value
            End Set
        End Property

        ''To check whether this control populated using DataSource or ViewState
        'Public Property UseDataSource() As String
        '    Get
        '        m_bUseDataSource = Convert.ToString(ViewState("UseDataSource"))
        '        Return m_bUseDataSource
        '    End Get
        '    Set(ByVal Value As String)
        '        m_bUseDataSource = Value
        '        ViewState("UseDataSource") = Value
        '    End Set
        'End Property

        ' Indicates the current mode of the control
        Public Property CurrentMode() As FormViewMode
            Get
                If ViewState("CurrentMode") Is Nothing Then
                    Return FormViewMode.ViewOnly
                End If
                Return CType([Enum].Parse(GetType(FormViewMode), ViewState("CurrentMode").ToString()), FormViewMode)
            End Get
            Set(ByVal Value As FormViewMode)
                ViewState("CurrentMode") = Value
            End Set
        End Property

        ' Indicates the style required for data items 
        <PersistenceMode(PersistenceMode.InnerProperty)> _
        Public ReadOnly Property ItemStyle() As TableItemStyle
            Get
                If m_oItemStyle Is Nothing Then
                    m_oItemStyle = New TableItemStyle
                End If

                If IsTrackingViewState Then
                    CType(m_oItemStyle, IStateManager).TrackViewState()
                End If
                Return m_oItemStyle
            End Get
        End Property

        ' Indicates the style required for alternating data items 
        <PersistenceMode(PersistenceMode.InnerProperty)> _
        Public ReadOnly Property AlternatingItemStyle() As TableItemStyle
            Get
                If m_oAltItemStyle Is Nothing Then
                    m_oAltItemStyle = New TableItemStyle
                End If

                If IsTrackingViewState Then
                    CType(m_oAltItemStyle, IStateManager).TrackViewState()
                End If

                Return m_oAltItemStyle
            End Get
        End Property

        ' Indicates the style required for the header
        <PersistenceMode(PersistenceMode.InnerProperty)> _
        Public ReadOnly Property HeaderStyle() As TableItemStyle
            Get
                If m_oHeaderStyle Is Nothing Then
                    m_oHeaderStyle = New TableItemStyle
                End If

                If IsTrackingViewState Then
                    CType(m_oHeaderStyle, IStateManager).TrackViewState()
                End If

                Return m_oHeaderStyle
            End Get
        End Property


        ' Indicates the style required for the header
        <PersistenceMode(PersistenceMode.InnerProperty)> _
        Public ReadOnly Property FooterStyle() As TableItemStyle
            Get
                If m_oFooterStyle Is Nothing Then
                    m_oFooterStyle = New TableItemStyle
                End If

                If IsTrackingViewState Then
                    CType(m_oFooterStyle, IStateManager).TrackViewState()
                End If

                Return m_oFooterStyle
            End Get
        End Property

        ' ***********************************************************
        ' PROPERTY:: TemplateUrl
        ' URL to a custom ASCX control to use for data display
        Public Property TemplateUrl() As String
            Get
                Return Convert.ToString(ViewState("TemplateUrl"))
            End Get
            Set(ByVal Value As String)
                ViewState("TemplateUrl") = Value
            End Set
        End Property

        ' Collection of internal items each representing a field of data
        <Browsable(False)> _
        Public Property Items() As FormViewItems
            Get
                If ViewState("Items") Is Nothing Then
                    ViewState("Items") = New FormViewItems
                End If
                Return CType(ViewState("Items"), FormViewItems)
            End Get
            Set(ByVal Value As FormViewItems)
                ViewState("Items") = Value
            End Set
        End Property

        Public Property DataSource() As Object
            Get
                Return m_oDataSource
            End Get
            Set(ByVal Value As Object)
                If (Value Is Nothing Or _
                    TypeOf (Value) Is DataTable Or _
                    TypeOf (Value) Is DataView) Then
                    m_oDataSource = Value
                Else
                    Throw New ArgumentException
                End If
            End Set
        End Property

        Public Property LayoutDataSource() As Object
            Get
                Return m_oLayoutDataSource
            End Get
            Set(ByVal Value As Object)
                If (Value Is Nothing Or _
                    TypeOf (Value) Is DataTable Or _
                    TypeOf (Value) Is DataView) Then
                    m_oLayoutDataSource = Value
                Else
                    Throw New ArgumentException
                End If
            End Set
        End Property

#End Region

#Region "Data Binding"

        ' Performs the data binding
        Public Overrides Sub DataBind()
            ' Call the base method
            MyBase.OnDataBinding(EventArgs.Empty)

            Controls.Clear()
            ClearChildViewState()
            TrackViewState()
            m_bUseDataSource = True
            CreateControlHierarchy()
            ChildControlsCreated = True
        End Sub

        ' Recreates the children using the saved view state
        Protected Overrides Sub CreateChildControls()
            Controls.Clear()
            If Not (ViewState("Items") Is Nothing) Then
                m_bUseDataSource = False
                CreateControlHierarchy()
            End If
        End Sub

        Protected Overrides Sub Render(ByVal writer As HtmlTextWriter)
            PrepareControlForRendering(writer)
            MyBase.RenderContents(writer)
        End Sub


        ' Create the graph of controls to be rendered
        Protected Overridable Sub CreateControlHierarchy()

            If m_bUseDataSource Then
                LoadItemsFromDataSource()
            End If

            ' Create the outermost table
            Dim oTable As New Table
            Controls.Add(oTable)

            ' Create the header row
            CreateHeader(oTable)

            ' Create all item rows
            If Items.Count = 0 Then
                CreateEmptyTable(oTable)
            Else
                CreateView(oTable)
            End If

            ' Create the footer row
            CreateFooter(oTable)

        End Sub

        ' Adjust the style of the various controls to display
        Protected Overridable Sub PrepareControlForRendering(ByVal writer As HtmlTextWriter)

            ' RECOMMENDED::
            ' Expose row objects (header, etc) through protected/public properties
            ' and set them when rows are physically created

            Dim oCtls As ControlCollection = Controls
            If oCtls.Count < 1 Then
                Return
            End If

            ' Configure the table
            Dim oTable As Table = oCtls(0)
            oTable.CopyBaseAttributes(Me)
            If (ControlStyleCreated) Then
                oTable.ApplyStyle(ControlStyle)
            End If

            ' Configure the items (including header and footer)
            Dim iRowsCount As Integer = oTable.Rows.Count

            ' Style the header (1st row in the table)
            Dim headerRow As TableRow = oTable.Rows(0)
            If Not (m_oHeaderStyle Is Nothing) Then
                headerRow.ApplyStyle(m_oHeaderStyle)
            Else
                headerRow.ApplyStyle(ControlStyle)
            End If

            'Prepare the alternating style by summing normal and alternating
            Dim altStyle As TableItemStyle = m_oItemStyle
            If Not (m_oAltItemStyle Is Nothing) Then
                altStyle = New TableItemStyle
                altStyle.CopyFrom(m_oItemStyle)
                altStyle.CopyFrom(m_oAltItemStyle)
            End If

            ' Style the rows corresponding to (alternating) data items
            For i As Integer = 1 To iRowsCount - 1
                Dim itemRow As TableRow = oTable.Rows(i)
                Dim itemStyle As TableItemStyle = m_oItemStyle
                If (i Mod 2) = 0 Then   ' start from 1
                    itemStyle = altStyle
                End If

                If Not (itemStyle Is Nothing) Then
                    itemRow.ApplyStyle(itemStyle)
                Else
                    itemRow.ApplyStyle(ControlStyle)
                End If

            Next

            ' Determine the footer and pager row
            Dim oFooterRow As TableRow = oTable.Rows(iRowsCount - 1)
            If Not (m_oFooterStyle Is Nothing) Then
                oFooterRow.ApplyStyle(m_oFooterStyle)
            Else
                oFooterRow.ApplyStyle(ControlStyle)
            End If

        End Sub

#End Region

#Region "Methods"

        Private Sub LoadItemsFromDataSource()

            Dim oDataView As DataView = ResolveLayoutDataSource()
            If oDataView Is Nothing Then
                Return
            End If

            Items.Clear()
            Dim iTotalVisibleRows As Integer = 0
            Dim oDataValueView As DataView = ResolveDataSource()
            Dim oDataViewRow As DataRowView = oDataValueView(0)

            For Each odrvItem As DataRowView In oDataView

                Dim sFieldName As String = odrvItem("field_name_txt") & String.Empty
                Dim sFieldKey As String = odrvItem("field_cd") & String.Empty
                Dim sCaption As String = odrvItem("display_name_txt") & String.Empty

                'Modified by Santosh 02/10/2014
                'Begin
                Dim sDataText As String = String.Empty
                If ColumnExists(oDataViewRow, sFieldName) Then
                    sDataText = oDataViewRow(sFieldName) & String.Empty
                End If
                'Dim sDataText As String = oDataViewRow(sFieldName) & String.Empty   '"Test Data"
                'End

                Dim sDataValue As String = sDataText '"TD" & String.Empty

                Dim sDataType As String = odrvItem("field_type_cd") & String.Empty

                Dim sChildFieldKey As String = odrvItem("child_field_cd") & String.Empty
                Dim sParentFieldKey As String = odrvItem("parent_field_cd") & String.Empty

                Dim bCascade As Boolean = False
                If Not odrvItem("cascade_ind") Is DBNull.Value Then
                    bCascade = odrvItem("cascade_ind")
                End If
                Dim bMandatory As Boolean = False
                If Not odrvItem("mand_ind") Is DBNull.Value Then
                    bMandatory = odrvItem("mand_ind")
                End If

                Dim bAllowView As Boolean = False
                If Not odrvItem("display_ind") Is DBNull.Value Then
                    bAllowView = odrvItem("display_ind")
                End If
                If bAllowView Then
                    iTotalVisibleRows = iTotalVisibleRows + 1
                End If

                Dim bAllowEdit As Boolean = False
                If Not odrvItem("edit_ind") Is DBNull.Value Then
                    bAllowEdit = odrvItem("edit_ind")
                End If

                Dim iSize As Integer = 0
                If Not odrvItem("size_nbr") Is DBNull.Value Then
                    iSize = odrvItem("size_nbr")
                End If

                Dim item As New FormViewItem(sFieldName, sFieldKey, sCaption, sDataValue, sDataText, sDataType, _
                            sChildFieldKey, sParentFieldKey, bCascade, bMandatory, bAllowView, bAllowEdit, iSize)

                Items.Add(item)

            Next

            Me.TotalVisibleRows = iTotalVisibleRows

        End Sub

        Private Function ResolveLayoutDataSource() As DataView

            If m_oLayoutDataSource Is Nothing Then
                Return Nothing
            End If

            If TypeOf (m_oLayoutDataSource) Is DataTable Then
                Return CType(m_oLayoutDataSource, DataTable).DefaultView
            End If

            If TypeOf (m_oLayoutDataSource) Is DataView Then
                Return CType(m_oLayoutDataSource, DataView)
            End If

        End Function

        Private Function ResolveDataSource() As DataView

            If m_oDataSource Is Nothing Then
                Return Nothing
            End If

            If TypeOf (m_oDataSource) Is DataTable Then
                Return CType(m_oDataSource, DataTable).DefaultView
            End If

            If TypeOf (m_oDataSource) Is DataView Then
                Return CType(m_oDataSource, DataView)
            End If

        End Function

        Public Function RetriveData() As FormViewItems

            Dim oItems As FormViewItems = Items
            For Each oItem As FormViewItem In oItems
                Dim sKey As String = oItem.FieldKey
                Dim oControl As Object = Me.FindControl("fv_" & sKey)
                If Not oControl Is Nothing Then
                    If oControl.GetType.Name = "TextBox" Then
                        Dim sText As String = oControl.Text
                        oItem.DataValue = sText
                        oItem.DataText = sText
                    ElseIf oControl.GetType.Name = "DropDownList" Then
                        If Not oControl.SelectedItem Is Nothing Then
                            oItem.DataValue = oControl.SelectedItem.Value
                            oItem.DataText = oControl.SelectedItem.Text
                        End If
                    ElseIf oControl.GetType.Name = "CheckBox" Then
                        Dim iVal As Int16 = oControl.Value
                        oItem.DataValue = iVal
                        oItem.DataText = iVal
                    End If
                End If
            Next

            Return oItems

        End Function


        ' Create the HTML structure for the header
        Private Sub CreateHeader(ByVal oTable As Table)
            ' Create the row
            Dim oRow As New TableRow
            oTable.Rows.Add(oRow)

            ' Add a cell
            Dim oCell As New TableCell

            'Assign Css Class Name
            Dim sCss As String = CssHeader
            If Not sCss = String.Empty Then
                oCell.CssClass = sCss
            End If

            oCell.ColumnSpan = 2
            oCell.Text = HeaderText
            oRow.Cells.Add(oCell)

            '' Add a second cell for View or Edit
            'If (CurrentMode <> FormViewMode.ViewOnly) Then
            '    Dim cellState As New TableCell
            '    cellState.Text = CurrentMode.ToString()
            '    oRow.Cells.Add(cellState)
            'End If
        End Sub

        ' Create the HTML structure for the footer
        Private Sub CreateFooter(ByVal t As Table)
            ' Create the row
            Dim oRow As New TableRow
            t.Rows.Add(oRow)

            ' Add a cell
            Dim oCell As New TableCell
            'Assign Css Class Name
            Dim sCss As String = CssFooter
            If Not sCss = String.Empty Then
                oCell.CssClass = sCss
            End If
            oCell.ColumnSpan = 2 '+ IIf(CurrentMode <> FormViewMode.ViewOnly, 1, 0)
            oCell.Text = FooterText
            oRow.Cells.Add(oCell)
        End Sub

        ' Create the HTML structure for the individual data item 
        Private Sub CreateItem(ByVal oTable As Table, ByVal oItem As FormViewItem)

            Dim oRow As New TableRow
            oTable.Rows.Add(oRow)
            If Not oItem.DataType.ToUpper() = "Filler".ToUpper() Then 'Santosh 02/10/2014
                ' Add the label 
                Dim oCell As New TableCell
                oCell.CssClass = CssCaption
                oCell.Text = oItem.Caption
                If oItem.Mandatory Then
                    oCell.Text = oCell.Text & " *"
                End If
                oRow.Cells.Add(oCell)

                ' Add the value 
                Dim oCell2 As New TableCell
                oRow.Cells.Add(oCell2)
                Select Case CurrentMode
                    Case FormViewMode.ViewOnly
                        oCell2 = CreateItemViewOnly(oCell2, oItem)
                    Case FormViewMode.Edit
                        oCell2 = CreateItemEdit(oCell2, oItem)
                End Select
            Else
                ' Add the label - used for instructions 'Santosh 02/10/2014
                Dim oCell As New TableCell
                If Not CssFillerCaption = String.Empty Then
                    oCell.CssClass = CssFillerCaption
                Else
                    oCell.CssClass = CssCaption
                End If

                oCell.Text = oItem.Caption
                If oItem.Mandatory Then
                    oCell.Text = oCell.Text & " *"
                End If
                oCell.ColumnSpan = 2
                oRow.Cells.Add(oCell)
            End If
        End Sub

        ' Create the item in view-only mode (pure text) 
        Private Function CreateItemViewOnly(ByVal oCell As TableCell, ByVal oItem As FormViewItem) As TableCell

            'Assign Css Class Name
            Dim sCss As String = CssValue
            If Not sCss = String.Empty Then
                oCell.CssClass = sCss
            End If
            RaiseCreateFieldEvent(oCell, oItem)
            oCell.Text = oItem.DataText
            Return oCell

        End Function

        ' Create the item in edit mode (textbox)
        Private Function CreateItemEdit(ByVal oCell As TableCell, ByVal oItem As FormViewItem) As TableCell

            Dim sCss As String = CssValue
            If Not sCss = String.Empty Then
                oCell.CssClass = sCss
            End If
            If oItem.AllowEdit Then
                If oItem.DataType.ToUpper = "TextBox".ToUpper Then
                    Dim oTextBox As New TextBox
                    sCss = CssTextBox
                    If Not sCss = String.Empty Then
                        oTextBox.CssClass = sCss
                    End If
                    oTextBox.ID = "fv_" & oItem.FieldKey
                    If oItem.Size > 0 Then
                        oTextBox.Width = Unit.Pixel(oItem.Size)
                    End If
                    oCell.Controls.Add(oTextBox)

                    RaiseCreateFieldEvent(oCell, oItem)

                    oTextBox.Text = oItem.DataText
                ElseIf oItem.DataType.ToUpper = "TextArea".ToUpper Then
                    Dim oTextBox As New TextBox
                    sCss = CssTextBox
                    If Not sCss = String.Empty Then
                        oTextBox.CssClass = sCss
                    End If
                    oTextBox.ID = "fv_" & oItem.FieldKey
                    oTextBox.TextMode = TextBoxMode.MultiLine
                    If oItem.Size > 0 Then
                        oTextBox.Width = Unit.Pixel(oItem.Size)
                    End If
                    oCell.Controls.Add(oTextBox)

                    RaiseCreateFieldEvent(oCell, oItem)

                    oTextBox.Text = oItem.DataText
                ElseIf oItem.DataType.ToUpper = "DropDown".ToUpper Then

                    Dim oDropDown As New DropDownList
                    sCss = CssDropDown
                    If Not sCss = String.Empty Then
                        oDropDown.CssClass = sCss
                    End If
                    oDropDown.ID = "fv_" & oItem.FieldKey
                    If oItem.Size > 0 Then
                        oDropDown.Width = Unit.Pixel(oItem.Size)
                    End If
                    oCell.Controls.Add(oDropDown)
                    RaiseCreateFieldEvent(oDropDown, oItem)

                    'If Casding Require then post back it to fetch records for details.
                    If oItem.Cascade = True Then
                        oDropDown.AutoPostBack = True
                        AddHandler oDropDown.SelectedIndexChanged, AddressOf DDLSelectedIndexChanged
                    End If

                    If m_bUseDataSource Then
                        If oDropDown.Items.Count > 0 Then
                            Dim sValue As String = oItem.DataValue
                            Dim oList As ListItem = oDropDown.Items.FindByValue(sValue)
                            If Not oList Is Nothing Then
                                oDropDown.SelectedValue = sValue
                            End If
                        End If
                    End If
                ElseIf oItem.DataType.ToUpper = "CheckBox".ToUpper Then
                    Dim oCheckBox As New CheckBox
                    sCss = CssCheckBox
                    If Not sCss = String.Empty Then
                        oCheckBox.CssClass = sCss
                    End If
                    oCheckBox.ID = "fv_" & oItem.FieldKey
                    oCell.Controls.Add(oCheckBox)
                    oCheckBox.Checked = CBool(oItem.DataValue)
                    RaiseCreateFieldEvent(oCell, oItem)
                Else
                    RaiseCreateFieldEvent(oCell, oItem)
                    oCell.Text = oItem.DataText
                End If
            Else
                RaiseCreateFieldEvent(oCell, oItem)
                oCell.Text = oItem.DataText
            End If
            Return oCell
        End Function

        Private Sub DDLSelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)

            Dim evtArgs As New DDLCascadeEventArgs
            Dim oItems As FormViewItems = Items
            For Each oItem As FormViewItem In oItems
                Dim sKey As String = "fv_" & oItem.FieldKey
                If sender.ID = sKey Then
                    evtArgs.FieldItem = oItem
                    Exit For
                End If
            Next
            RaiseEvent DDLCascade(sender, evtArgs)
        End Sub

        ' Govern the generation of the HTML markup for the data items 
        Private Sub CreateView(ByVal oTable As Table)

            oTable.Width = Unit.Percentage(100)

            If TemplateUrl <> "" Then
                CreateTemplateItem(oTable)
                Return
            End If

            Dim iColCount As Integer = Me.ColumnCount
            Dim iTotalVisibleRows As Integer = Me.TotalVisibleRows
            Dim iCount As Integer = 1
            Dim oColTable As New Table
            Dim oMainRow As TableRow
            Dim oMainCell As TableCell

            Dim oDataTable As Table
            Dim oDataRow As New TableRow
            For Each oItem As FormViewItem In Items
                If oItem.AllowView Then
                    If iColCount < 2 Then
                        CreateItem(oTable, oItem)
                    ElseIf iColCount >= 2 Then
                        If IsNewColStart(iCount, iTotalVisibleRows, iColCount) Then
                            'For multiple columns add a merged cell to the main table in which all columns..
                            oDataTable = New Table

                            Dim oCell As New TableCell
                            oCell.VerticalAlign = VerticalAlign.Top
                            oCell.Controls.Add(oDataTable)
                            oDataRow.Cells.Add(oCell)
                            oColTable.Rows.Add(oDataRow)
                            If iCount Then
                                oMainRow = New TableRow
                                oTable.Rows.Add(oMainRow)
                                oMainCell = New TableCell
                                oMainCell.ColumnSpan = 2
                                oMainRow.Cells.Add(oMainCell)
                                oColTable.Width = Unit.Percentage(100)
                                oMainCell.Controls.Add(oColTable)
                            End If
                        End If
                        CreateItem(oDataTable, oItem)
                        iCount = iCount + 1
                    End If
                End If
            Next
        End Sub

        'Private Function IsNewColStart(ByVal iCount As Integer, ByVal iTotalVisibleRows As Integer, ByVal iColCount As Integer) As Boolean
        '    If iCount = 1 Then
        '        Return True
        '    Else
        '        Dim iMaxRow As Integer
        '        Dim iRemainder As Integer
        '        Dim iCurrCol As Integer
        '        iMaxRow = iTotalVisibleRows \ iColCount
        '        iRemainder = iTotalVisibleRows Mod iColCount
        '        iCurrCol = iCount \ iColCount
        '        If (iCount = ((iMaxRow * iCurrCol) + iRemainder)) Then
        '            If iCurrCol < iColCount Then
        '                Return True
        '            End If
        '        End If
        '        End If
        '    Return False
        'End Function

        'Temp fix for two column display : need to implement for generic use.
        Private Function IsNewColStart(ByVal iCount As Integer, ByVal iTotalVisibleRows As Integer, ByVal iColCount As Integer) As Boolean
            If iCount = 1 Then
                Return True
            Else
                If iColCount = 2 Then
                    If iCount > (iTotalVisibleRows / 2) Then
                        If Not m_blIsColAdded Then
                            m_blIsColAdded = True
                            Return True
                        End If
                    End If
                End If
            End If
            Return False
        End Function

        Private Sub CreateEmptyTable(ByVal oTable As Table)
            ' Create the row
            Dim oRow As New TableRow
            oTable.Rows.Add(oRow)

            ' Add a cell
            Dim oCell As New TableCell
            oCell.ColumnSpan = 2
            oCell.Text = String.Empty  'EmptyText
            oRow.Cells.Add(oCell)
        End Sub

        Private Sub CreateTemplateItem(ByVal oTable As Table)
            ' Create the row
            Dim oRow As New TableRow
            oTable.Rows.Add(oRow)

            ' Add a cell
            Dim oCell As New TableCell
            oCell.ColumnSpan = 2
            oRow.Cells.Add(oCell)

            'Load the User Control
            Dim oUserControl As UserControl = Page.LoadControl(TemplateUrl)
            If oUserControl Is Nothing Then
                Return
            End If
            oCell.Controls.Add(oUserControl)
            For Each oItem As FormViewItem In Items
                InitTemplateItem(oUserControl, oItem)
            Next

        End Sub

        Private Sub InitTemplateItem(ByVal oUserControl As UserControl, ByVal oItem As FormViewItem)

            Dim oControlID As String = "fv_" & oItem.FieldKey
            Dim oLabel As Label
            oLabel = oUserControl.FindControl(oControlID & "_Title")
            oLabel.Text = oItem.Caption
            If oItem.Mandatory Then
                oLabel.Text = oLabel.Text & " *"
            End If

            If oItem.DataType.ToUpper = "TextBox".ToUpper Then
                Dim oTextBox As TextBox
                oTextBox = oUserControl.FindControl(oControlID)
                'RaiseCreateFieldEvent(oTextBox, oItem)
                oTextBox.Text = oItem.DataText
            ElseIf oItem.DataType.ToUpper = "DropDown".ToUpper Then
                Dim oDropDown As DropDownList
                oDropDown = oUserControl.FindControl(oControlID)
                RaiseCreateFieldEvent(oDropDown, oItem)
                If oItem.Cascade = True Then
                    oDropDown.AutoPostBack = True
                    AddHandler oDropDown.SelectedIndexChanged, AddressOf DDLSelectedIndexChanged
                End If
                If m_bUseDataSource Then
                    If oDropDown.Items.Count > 0 Then
                        Dim sValue As String = oItem.DataValue
                        Dim oList As ListItem = oDropDown.Items.FindByValue(sValue)
                        If Not oList Is Nothing Then
                            oDropDown.SelectedValue = sValue
                        End If
                    End If
                End If
            ElseIf oItem.DataType.ToUpper = "CheckBox".ToUpper Then
                Dim oCheckBox As CheckBox
                oCheckBox = oUserControl.FindControl(oControlID)
                'RaiseCreateFieldEvent(oCheckBox, oItem)
                oCheckBox.Checked = CBool(oItem.DataValue)
            ElseIf oItem.DataType.ToUpper = "Label".ToUpper Then
                Dim oLabel1 As Label
                oLabel1 = oUserControl.FindControl(oControlID)
                oLabel1.Text = oItem.DataText
            End If
        End Sub

        Private Sub RaiseCreateFieldEvent(ByVal oControl As WebControl, ByVal oItem As FormViewItem)
            Dim evtArgs As New CreateFieldEventArgs
            evtArgs.FieldItem = oItem
            evtArgs.Control = oControl
            RaiseEvent CreateField(Me, evtArgs)
        End Sub

        'Protected Overrides Function OnBubbleEvent(ByVal source As Object, ByVal args As System.EventArgs) As Boolean
        '    'If args.GetType.Name = "DDLCascadeEventArgs" Then

        '    'End If
        'End Function

        'Private Function GetFieldItem("") as FormViewItem

        'End Function

        Function ColumnExists(ByVal rowData As DataRowView, ByVal column As String) As Boolean
            Return rowData.Row.Table.Columns.Contains(column)
        End Function

#End Region

#Region "View State Management"

        ' Override viewstate restoration to manage styles
        Protected Overrides Sub LoadViewState(ByVal savedState As Object)
            Dim baseState As Object = Nothing
            Dim oState() As Object = Nothing

            If Not (savedState Is Nothing) Then
                oState = CType(savedState, Object())
                baseState = oState(0)
            End If

            ' Do as usual
            MyBase.LoadViewState(baseState)

            ' Handle custom state
            If oState Is Nothing Then
                Return
            End If

            ' Restores ItemStyle
            If Not (oState(1) Is Nothing) Then
                CType(ItemStyle, IStateManager).LoadViewState(oState(1))
            End If

            ' Restores AlternatingItemStyle
            If Not (oState(2) Is Nothing) Then
                CType(AlternatingItemStyle, IStateManager).LoadViewState(oState(2))
            End If

            ' Restores HeaderStyle
            If Not (oState(3) Is Nothing) Then
                CType(HeaderStyle, IStateManager).LoadViewState(oState(3))
            End If

            ' Restores FooterStyle
            If Not (oState(4) Is Nothing) Then
                CType(FooterStyle, IStateManager).LoadViewState(oState(4))
            End If

        End Sub

        ' Override viewstate storage to manage styles
        Protected Overrides Function SaveViewState() As Object
            Dim oState(5) As Object

            ' Store the default viewstate
            oState(0) = MyBase.SaveViewState()

            ' Store the ItemStyle property
            If m_oItemStyle Is Nothing Then
                oState(1) = Nothing
            Else
                oState(1) = CType(m_oItemStyle, IStateManager).SaveViewState()
            End If

            ' Store the AlternatingItemStyle property
            If m_oAltItemStyle Is Nothing Then
                oState(2) = Nothing
            Else
                oState(2) = CType(m_oAltItemStyle, IStateManager).SaveViewState()
            End If

            ' Store the HeaderStyle property
            If m_oHeaderStyle Is Nothing Then
                oState(3) = Nothing
            Else
                oState(3) = CType(m_oHeaderStyle, IStateManager).SaveViewState()
            End If

            ' Store the FooterStyle property
            If m_oFooterStyle Is Nothing Then
                oState(4) = Nothing
            Else
                oState(4) = CType(m_oFooterStyle, IStateManager).SaveViewState()
            End If

            Return oState
        End Function

        ' Override viewstate tracking
        Protected Overrides Sub TrackViewState()
            MyBase.TrackViewState()

            ' Track view state for the ItemStyle property
            If Not (m_oItemStyle Is Nothing) Then
                CType(m_oItemStyle, IStateManager).TrackViewState()
            End If

            ' Track view state for the AlternatingItemStyle property
            If Not (m_oAltItemStyle Is Nothing) Then
                CType(m_oAltItemStyle, IStateManager).TrackViewState()
            End If

            ' Track view state for the HeaderStyle property
            If Not (m_oHeaderStyle Is Nothing) Then
                CType(m_oHeaderStyle, IStateManager).TrackViewState()
            End If

            ' Track view state for the FooterStyle property
            If Not (m_oFooterStyle Is Nothing) Then
                CType(m_oFooterStyle, IStateManager).TrackViewState()
            End If
        End Sub

#End Region


    End Class

End Namespace