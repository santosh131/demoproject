Imports System.ComponentModel
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Collections

Namespace MaxWebUI.FormView

    <Serializable()> _
    Public Class FormViewItems : Inherits CollectionBase

        Public Sub Add(ByVal value As FormViewItem)
            InnerList.Add(value)
        End Sub

        Default Property Item(ByVal index As Integer) As FormViewItem
            Get
                Return CType(InnerList.Item(index), FormViewItem)
            End Get
            Set(ByVal Value As FormViewItem)
                InnerList.Item(index) = Value
            End Set
        End Property

    End Class
End Namespace